# 📚 BookNest – Online Book Store (Frontend + Backend System)

A complete online book store with a **working backend**: user accounts, book catalog, shopping cart,
orders with stock control, and an admin panel. Built with **HTML, CSS, vanilla JavaScript** (frontend) and
**Node.js + Express + SQLite** (real server).

> Project for *Modern Web Programming* – Online Book Store Backend System.

## ▶️ Run it – 2 ways

### Way 1: Just open `index.html` (nothing to install)
Double-click **`index.html`** (or in VS Code: right-click → **Open with Live Server**).

The backend runs **inside the browser** (`js/api-local.js`) and keeps its database in `localStorage`.
It follows the same rules as the Node server: hashed passwords, login tokens, admin-only actions,
stock checks and all-or-nothing checkout.

### Way 2: With the real Node.js server
```bash
cd server
npm install
npm start          # API runs at http://localhost:3000
```
Then open `index.html`, click the **🧪 Browser backend** badge at the top → choose **🖥️ Node server** →
**Test connection** → **Save & connect**. Now every request goes over HTTP to Express and is stored in an SQLite database file.
(Full server documentation: [`server/README.md`](server/README.md).)

> **Bonus:** the server also serves its own simple store front. With the server running, open <http://localhost:3000>
> (Windows: double-click `server/start.bat`, which installs, starts the server and opens the browser for you).

### Demo accounts
| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@bookstore.com` | `Admin@123` |
| Customer | `student@example.com` | `Student@123` |

(The login page has one-click buttons for both.)

## ✨ What you can do
| Customer | Admin |
|----------|-------|
| Browse, search, filter by category and price, sort, paginate | Dashboard: customers, books, orders, revenue, top sellers |
| Book details popup, stock badges (In stock / Only 3 left / Out of stock) | Add, edit and delete books |
| Register, log in, log out (session survives page reload) | See all orders; mark **shipped → delivered** or cancel |
| Cart: add, change quantity, remove | List all users |
| Checkout with shipping address; order history; cancel an order (stock returns) | |

**📡 API log:** click *Show API log* in the footer to watch every request (`GET /api/books …  200`, `POST /api/orders … 201`)
as it happens, in both modes. Great for explaining the backend in a demo.

## 🧱 How it is built
```
 Screens (app.js)  ──►  api.listBooks(), api.checkout(), …   (same methods in both modes)
                          │
              ┌───────────┴────────────┐
      api-local.js                api-remote.js
   backend inside the         fetch() calls to the Node
   browser + localStorage     server (Express + SQLite)
```
Because both back ends offer the same methods and return the same JSON, `app.js` never needs to know which one it uses.

## 📁 Folder structure
```
BookStore-FullStack/
├── index.html             # the app (open this)
├── css/style.css          # styling, fully responsive
├── js/
│   ├── seed-data.js       # 26 sample books
│   ├── api-local.js       # backend running in the browser
│   ├── api-remote.js      # connector to the real Node server
│   └── app.js             # screens: shop, cart, orders, login, admin
├── server/                # real backend (Node + Express + SQLite) with its own README and 15 tests
├── README.md  LICENSE  .gitignore
```

## 🧠 Concepts used (useful for viva)
- **Client–server architecture** and **REST API** (resources, HTTP verbs, status codes, JSON)
- **Authentication** (password hashing with PBKDF2 in the browser / bcrypt on the server, token sessions, JWT on the server)
- **Authorisation** – role-based access (customer vs admin), admin-only endpoints
- **Relational data** – users, books, cart items, orders, order items (SQLite on the server)
- **Transactions** – checkout checks all stock first, then changes everything together or nothing
- **Server-side validation** (never trust the browser) with clear error messages
- **Abstraction** – one API interface with two interchangeable back ends
- **Security basics** – parameterised SQL, escaped HTML output (XSS), Helmet headers, CORS, login rate-limit
- Frontend: DOM manipulation, `fetch` + `async/await`, event delegation, hash routing (`#/cart`), responsive CSS Grid/Flexbox

## ⚠️ Good to know
- *Browser backend* data lives only in your browser, so it is **not shared** between devices. Use the Node server for real shared data.
- The browser backend is a teaching/demo version of the server logic. For anything real, use the Node server.
- Prices and ratings are sample values.

## 📄 License
MIT – see [LICENSE](LICENSE).
