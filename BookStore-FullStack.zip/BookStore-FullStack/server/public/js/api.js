"use strict";

/*
 * Talks to the backend. When this page is opened from the server (http://localhost:3000)
 * it uses the same address. If you double-click index.html (file://) it still works,
 * as long as the server is running on port 3000.
 */
const API_BASE = location.protocol === "file:" ? "http://localhost:3000" : "";
const TOKEN_KEY = "pageturner_token";

const Session = {
  get token() {
    try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
  },
  set token(value) {
    try {
      if (value) localStorage.setItem(TOKEN_KEY, value);
      else localStorage.removeItem(TOKEN_KEY);
    } catch { /* storage blocked: user stays logged in until refresh */ }
  },
};

class ApiError extends Error {
  constructor(message, status, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

async function api(method, path, body) {
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (Session.token) headers.Authorization = `Bearer ${Session.token}`;

  let res;
  try {
    res = await fetch(API_BASE + path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError("Cannot reach the server. Start it with:  npm start", 0);
  }

  if (res.status === 204) return null;
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }

  if (!res.ok) {
    let message = (data && data.error) || `Request failed (${res.status})`;
    if (data && data.details) message += ": " + Object.values(data.details).join(", ");
    throw new ApiError(message, res.status, data && data.details);
  }
  return data;
}
