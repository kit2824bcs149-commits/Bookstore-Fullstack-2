"use strict";

/* ===================== Helpers ===================== */
const $ = (id) => document.getElementById(id);
const view = $("view");
const rupee = (n) => "₹" + Number(n).toLocaleString("en-IN");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const dateText = (s) => new Date(s.replace(" ", "T") + "Z").toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

function coverGradient(title) {
  let h = 0;
  for (const ch of title) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const h1 = h % 360, h2 = (h1 + 40 + ((h >> 8) % 60)) % 360;
  return `linear-gradient(155deg, hsl(${h1} 55% 32%), hsl(${h2} 60% 22%))`;
}

let toastTimer;
function toast(msg, isError = false) {
  const el = $("toast");
  el.textContent = msg;
  el.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}

/** Runs an async action and shows any error as a toast. */
async function attempt(fn) {
  try {
    return await fn();
  } catch (err) {
    if (err.status === 401 && Session.token) { Session.token = null; state.user = null; renderHeader(); }
    toast(err.message, true);
    $("server-banner").classList.toggle("hidden", err.status !== 0);
    if (err.status === 0) $("server-banner").textContent = err.message;
  }
}

/* ===================== State ===================== */
const state = {
  user: null,
  cart: { items: [], itemCount: 0, total: 0 },
  shop: { search: "", category: "", sort: "newest", page: 1 },
  adminTab: "dashboard",
};

/* ===================== Modal ===================== */
const modal = $("modal");
function openModal(html) {
  $("modal-body").innerHTML = html;
  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  const first = modal.querySelector("input, textarea, select, button.btn");
  if (first) first.focus();
}
function closeModal() {
  modal.classList.add("hidden");
  document.body.style.overflow = "";
}
$("modal-close").addEventListener("click", closeModal);
modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

/* ===================== Header / session ===================== */
function renderHeader() {
  const u = state.user;
  $("nav-orders").classList.toggle("hidden", !u);
  $("nav-admin").classList.toggle("hidden", !(u && u.role === "admin"));
  $("cart-count").textContent = state.cart.itemCount;
  $("user-box").innerHTML = u
    ? `<span class="user-name">${esc(u.name)}${u.role === "admin" ? '<span class="role-tag">admin</span>' : ""}</span>
       <button class="btn outline small" type="button" data-action="logout">Logout</button>`
    : `<button class="btn small" type="button" data-action="login">Login / Register</button>`;
  const route = currentRoute();
  document.querySelectorAll("[data-route]").forEach((a) => a.classList.toggle("active", a.dataset.route === route));
}

async function loadSession() {
  state.user = null;
  state.cart = { items: [], itemCount: 0, total: 0 };
  if (Session.token) {
    try {
      state.user = (await api("GET", "/api/auth/me")).user;
      state.cart = await api("GET", "/api/cart");
    } catch (err) {
      if (err.status === 401) Session.token = null;
    }
  }
  renderHeader();
}

function logout() {
  Session.token = null;
  state.user = null;
  state.cart = { items: [], itemCount: 0, total: 0 };
  renderHeader();
  toast("Logged out");
  location.hash = "#/";
  route();
}

/* ===================== Login / register modal ===================== */
function openAuthModal(mode = "login") {
  const isLogin = mode === "login";
  openModal(`
    <h2>${isLogin ? "Login" : "Create account"}</h2>
    <form data-form="${mode}" novalidate>
      ${isLogin ? "" : '<div class="field"><label for="f-name">Full name</label><input id="f-name" name="name" autocomplete="name" /></div>'}
      <div class="field"><label for="f-email">Email</label><input id="f-email" name="email" type="email" autocomplete="email" /></div>
      <div class="field"><label for="f-pass">Password ${isLogin ? "" : "(min 8 characters)"}</label>
        <input id="f-pass" name="password" type="password" autocomplete="${isLogin ? "current-password" : "new-password"}" /></div>
      <p class="form-error" id="form-error"></p>
      <button class="btn block" type="submit">${isLogin ? "Login" : "Register"}</button>
    </form>
    <p class="muted" style="margin-top:12px">
      ${isLogin ? 'New here? <a href="#" data-action="show-register" style="color:var(--primary)">Create an account</a>'
                : 'Already registered? <a href="#" data-action="show-login" style="color:var(--primary)">Login</a>'}
    </p>
    ${isLogin ? `<div class="hint">Demo accounts:<br>
      <button class="btn outline small" type="button" data-demo="student@example.com|Student@123">Customer</button>
      <button class="btn outline small" type="button" data-demo="admin@bookstore.com|Admin@123">Admin</button></div>` : ""}`);
}

async function submitAuth(form) {
  const data = Object.fromEntries(new FormData(form));
  const mode = form.dataset.form;
  const errBox = $("form-error");
  errBox.textContent = "";
  try {
    const res = await api("POST", `/api/auth/${mode}`, data);
    Session.token = res.token;
    closeModal();
    await loadSession();
    $("server-banner").classList.add("hidden");
    toast(`Welcome, ${res.user.name}!`);
    route();
  } catch (err) {
    errBox.textContent = err.message;
  }
}

/* ===================== Cart actions ===================== */
async function addToCart(bookId, quantity = 1) {
  if (!state.user) { openAuthModal("login"); toast("Please login to add books to your cart"); return; }
  const cart = await attempt(() => api("POST", "/api/cart", { bookId, quantity }));
  if (cart) { state.cart = cart; renderHeader(); toast("Added to cart 🛒"); }
}

/* ===================== Shop page ===================== */
function bookCard(b) {
  const stock = b.stock === 0 ? '<span class="stock out">Out of stock</span>'
    : b.stock <= 5 ? `<span class="stock low">Only ${b.stock} left</span>` : '<span class="stock in">In stock</span>';
  return `
    <article class="card">
      <button class="cover" type="button" data-open-book="${b.id}" style="--cover-bg:${coverGradient(b.title)}" aria-label="Details of ${esc(b.title)}">
        <span class="cover-cat">${esc(b.category)}</span>
        <span class="cover-title">${esc(b.title)}</span>
        <span class="cover-author">${esc(b.author)}</span>
      </button>
      <div class="card-body">
        <h3 class="card-title" data-open-book="${b.id}">${esc(b.title)}</h3>
        <p class="card-author">${esc(b.author)}</p>
        ${stock}
        <div class="card-meta"><span class="price">${rupee(b.price)}</span>${b.rating ? `<span class="rating">★ ${b.rating.toFixed(1)}</span>` : ""}</div>
        <button class="btn" type="button" data-add="${b.id}" ${b.stock === 0 ? "disabled" : ""}>${b.stock === 0 ? "Unavailable" : "Add to cart"}</button>
      </div>
    </article>`;
}

let booksCache = new Map();

async function renderShop() {
  const s = state.shop;
  if (!$("shop-root")) {
    view.innerHTML = `
      <div id="shop-root">
        <h1 class="page-title">Find your next favourite book</h1>
        <p class="page-sub">Browse the store, add books to your cart and place an order.</p>
        <div class="toolbar">
          <input id="shop-search" type="search" placeholder="Search by title, author or category..." value="${esc(s.search)}" aria-label="Search books" />
          <select id="shop-sort" aria-label="Sort by">
            <option value="newest">Newest</option><option value="title-asc">Title (A–Z)</option>
            <option value="price-asc">Price: Low to High</option><option value="price-desc">Price: High to Low</option>
            <option value="rating-desc">Top Rated</option><option value="year-desc">Newest published</option>
          </select>
        </div>
        <div id="shop-chips" class="chips" role="group" aria-label="Categories"></div>
        <p id="shop-info" class="info" role="status"></p>
        <div id="shop-grid" class="book-grid"></div>
        <nav id="shop-pager" class="pagination" aria-label="Pagination"></nav>
      </div>`;
    $("shop-sort").value = s.sort;
    api("GET", "/api/books/categories").then((r) => {
      $("shop-chips").innerHTML = ["", ...r.data.map((c) => c.name)]
        .map((c) => `<button class="chip" type="button" data-cat="${esc(c)}" aria-pressed="${c === s.category}">${c || "All"}</button>`).join("");
    }).catch(() => {});
  }

  const qs = new URLSearchParams({ page: s.page, limit: 8, sort: s.sort });
  if (s.search) qs.set("search", s.search);
  if (s.category) qs.set("category", s.category);

  const res = await attempt(() => api("GET", `/api/books?${qs}`));
  if (!res) { $("shop-info").textContent = "Could not load books."; return; }
  $("server-banner").classList.add("hidden");

  res.data.forEach((b) => booksCache.set(b.id, b));
  $("shop-grid").innerHTML = res.data.map(bookCard).join("") || '<div class="empty" style="grid-column:1/-1">📭 No books match your search.</div>';
  const p = res.pagination;
  $("shop-info").textContent = p.total ? `Showing ${(p.page - 1) * p.limit + 1}–${(p.page - 1) * p.limit + res.data.length} of ${p.total} books` : "";
  let pager = "";
  if (p.totalPages > 1) {
    pager = `<button class="page-btn" type="button" data-page="${p.page - 1}" ${p.page === 1 ? "disabled" : ""}>← Prev</button>`;
    for (let i = 1; i <= p.totalPages; i++) pager += `<button class="page-btn" type="button" data-page="${i}" ${i === p.page ? 'aria-current="page"' : ""}>${i}</button>`;
    pager += `<button class="page-btn" type="button" data-page="${p.page + 1}" ${p.page === p.totalPages ? "disabled" : ""}>Next →</button>`;
  }
  $("shop-pager").innerHTML = pager;
  document.querySelectorAll("#shop-chips .chip").forEach((c) => c.setAttribute("aria-pressed", String(c.dataset.cat === s.category)));
}

function openBook(id) {
  const b = booksCache.get(id);
  if (!b) return;
  openModal(`
    <div class="modal-flex">
      <div class="cover" style="--cover-bg:${coverGradient(b.title)}">
        <span class="cover-cat">${esc(b.category)}</span><span class="cover-title">${esc(b.title)}</span><span class="cover-author">${esc(b.author)}</span>
      </div>
      <div>
        <h2>${esc(b.title)}</h2>
        <p class="muted">by ${esc(b.author)}</p>
        <p style="margin:10px 0">${esc(b.description || "No description available.")}</p>
        <p><b>Category:</b> ${esc(b.category)} &nbsp; <b>Published:</b> ${b.year || "–"}${b.rating ? ` &nbsp; <b>Rating:</b> ★ ${b.rating.toFixed(1)}` : ""}</p>
        <p style="margin:8px 0"><span class="price">${rupee(b.price)}</span> &nbsp; ${b.stock ? `<span class="stock in">${b.stock} in stock</span>` : '<span class="stock out">Out of stock</span>'}</p>
        <button class="btn" type="button" data-add="${b.id}" ${b.stock ? "" : "disabled"}>Add to cart</button>
      </div>
    </div>`);
}

/* ===================== Cart page ===================== */
function renderCart() {
  if (!state.user) {
    view.innerHTML = `<div class="empty">🔒 Please login to see your cart.<br><br><button class="btn" type="button" data-action="login">Login / Register</button></div>`;
    return;
  }
  const c = state.cart;
  if (c.items.length === 0) {
    view.innerHTML = `<h1 class="page-title">Your cart</h1><div class="empty">🛒 Your cart is empty.<br><br><a class="btn" href="#/">Browse books</a></div>`;
    return;
  }
  view.innerHTML = `
    <h1 class="page-title">Your cart</h1>
    <div class="cart-layout">
      <div class="panel"><div class="table-wrap"><table>
        <thead><tr><th>Book</th><th class="num">Price</th><th>Quantity</th><th class="num">Total</th><th></th></tr></thead>
        <tbody>${c.items.map((i) => `
          <tr>
            <td><b>${esc(i.title)}</b><br><span class="muted">${esc(i.author)}</span></td>
            <td class="num">${rupee(i.price)}</td>
            <td><span class="qty">
              <button type="button" data-qty="${i.bookId}|${i.quantity - 1}" aria-label="Decrease">−</button>
              <b>${i.quantity}</b>
              <button type="button" data-qty="${i.bookId}|${i.quantity + 1}" aria-label="Increase" ${i.quantity >= i.stock ? "disabled" : ""}>+</button>
            </span></td>
            <td class="num">${rupee(i.lineTotal)}</td>
            <td><button class="btn danger small" type="button" data-remove="${i.bookId}">Remove</button></td>
          </tr>`).join("")}</tbody></table></div></div>
      <form class="panel" data-form="checkout" novalidate>
        <h2>Order summary</h2>
        <div class="summary-row"><span>Items</span><span>${c.itemCount}</span></div>
        <div class="summary-row total"><span>Total</span><span>${rupee(c.total)}</span></div>
        <div class="field" style="margin-top:14px"><label for="addr">Shipping address</label>
          <textarea id="addr" name="shippingAddress" rows="3" placeholder="House no, street, city, PIN code"></textarea></div>
        <p class="form-error" id="form-error"></p>
        <button class="btn block" type="submit">Place order</button>
        <button class="btn outline block small" type="button" data-action="clear-cart" style="margin-top:8px">Empty cart</button>
      </form>
    </div>`;
}

async function changeQty(bookId, qty) {
  const cart = await attempt(() => qty < 1 ? api("DELETE", `/api/cart/${bookId}`) : api("PUT", `/api/cart/${bookId}`, { quantity: qty }));
  if (cart) { state.cart = cart; renderHeader(); renderCart(); }
}

async function placeOrder(form) {
  const errBox = $("form-error");
  errBox.textContent = "";
  try {
    await api("POST", "/api/orders", { shippingAddress: form.shippingAddress.value });
    state.cart = await api("GET", "/api/cart");
    renderHeader();
    toast("Order placed successfully 🎉");
    location.hash = "#/orders";
  } catch (err) {
    errBox.textContent = err.message;
  }
}

/* ===================== Orders page ===================== */
function orderCard(o, { admin = false } = {}) {
  const NEXT = { placed: ["shipped", "cancelled"], shipped: ["delivered"], delivered: [], cancelled: [] };
  const controls = admin
    ? (NEXT[o.status].length ? `<select data-set-status="${o.id}" aria-label="Change status"><option value="">Change status…</option>${NEXT[o.status].map((s) => `<option value="${s}">${s}</option>`).join("")}</select>` : "")
    : (o.status === "placed" ? `<button class="btn danger small" type="button" data-cancel="${o.id}">Cancel order</button>` : "");
  return `
    <div class="order">
      <div class="order-head">
        <div><b>Order #${o.id}</b> <span class="muted">· ${dateText(o.created_at)}</span>${admin ? `<br><span class="muted">${esc(o.customerName)} (${esc(o.customerEmail)})</span>` : ""}</div>
        <span class="pill ${o.status}">${o.status}</span>
      </div>
      ${o.items ? `<ul>${o.items.map((i) => `<li><span>${esc(i.title)} × ${i.quantity}</span><span>${rupee(i.lineTotal)}</span></li>`).join("")}</ul>` : ""}
      <div class="order-head" style="margin:6px 0 0">
        <span class="muted">Ship to: ${esc(o.shipping_address)}</span>
        <b>${rupee(o.total)}</b>
      </div>
      ${controls ? `<div style="margin-top:10px">${controls}</div>` : ""}
    </div>`;
}

async function renderOrders() {
  if (!state.user) { location.hash = "#/"; return; }
  view.innerHTML = `<h1 class="page-title">My orders</h1><p class="info">Loading…</p>`;
  const res = await attempt(() => api("GET", "/api/orders"));
  if (!res) return;
  view.innerHTML = `<h1 class="page-title">My orders</h1>` +
    (res.data.length ? res.data.map((o) => orderCard(o)).join("") : `<div class="empty">📦 You have not placed any orders yet.<br><br><a class="btn" href="#/">Start shopping</a></div>`);
}

/* ===================== Admin pages ===================== */
async function renderAdmin() {
  if (!state.user || state.user.role !== "admin") {
    view.innerHTML = `<div class="empty">🔒 Admin access only.<br><br><button class="btn" type="button" data-action="login">Login as admin</button></div>`;
    return;
  }
  const tabs = ["dashboard", "books", "orders", "users"];
  view.innerHTML = `<h1 class="page-title">Admin panel</h1>
    <div class="tabs">${tabs.map((t) => `<button class="chip" type="button" data-admin-tab="${t}" aria-pressed="${t === state.adminTab}">${t[0].toUpperCase() + t.slice(1)}</button>`).join("")}</div>
    <div id="admin-body"><p class="info">Loading…</p></div>`;
  const body = $("admin-body");
  const tab = state.adminTab;

  if (tab === "dashboard") {
    const s = await attempt(() => api("GET", "/api/admin/stats"));
    if (!s) return;
    body.innerHTML = `
      <div class="stats">
        <div class="stat"><span>Customers</span><strong>${s.users}</strong></div>
        <div class="stat"><span>Books</span><strong>${s.books}</strong></div>
        <div class="stat"><span>Out of stock</span><strong>${s.outOfStock}</strong></div>
        <div class="stat"><span>Orders</span><strong>${s.orders}</strong></div>
        <div class="stat"><span>Revenue</span><strong>${rupee(s.revenue)}</strong></div>
      </div>
      <div class="panel"><h2>Orders by status</h2>${s.ordersByStatus.length ? s.ordersByStatus.map((o) => `<span class="pill ${o.status}" style="margin-right:8px">${o.status}: ${o.count}</span>`).join("") : '<p class="muted">No orders yet.</p>'}</div>
      <div class="panel"><h2>Top selling books</h2>${s.topBooks.length ? `<table><thead><tr><th>Title</th><th class="num">Copies sold</th></tr></thead><tbody>${s.topBooks.map((b) => `<tr><td>${esc(b.title)}</td><td class="num">${b.sold}</td></tr>`).join("")}</tbody></table>` : '<p class="muted">No sales yet.</p>'}</div>`;
  } else if (tab === "books") {
    const res = await attempt(() => api("GET", "/api/books?limit=50&sort=title-asc"));
    if (!res) return;
    res.data.forEach((b) => booksCache.set(b.id, b));
    body.innerHTML = `
      <div class="panel">
        <div class="order-head"><h2>Manage books (${res.pagination.total})</h2><button class="btn small" type="button" data-book-form="new">+ Add book</button></div>
        <div class="table-wrap"><table>
          <thead><tr><th>Title</th><th>Category</th><th class="num">Price</th><th class="num">Stock</th><th></th></tr></thead>
          <tbody>${res.data.map((b) => `<tr>
            <td><b>${esc(b.title)}</b><br><span class="muted">${esc(b.author)}</span></td><td>${esc(b.category)}</td>
            <td class="num">${rupee(b.price)}</td><td class="num">${b.stock}</td>
            <td><span class="actions"><button class="btn outline small" type="button" data-book-form="${b.id}">Edit</button>
            <button class="btn danger small" type="button" data-delete-book="${b.id}">Delete</button></span></td></tr>`).join("")}</tbody>
        </table></div>
        ${res.pagination.totalPages > 1 ? '<p class="muted" style="margin-top:8px">Showing the first 50 books.</p>' : ""}
      </div>`;
  } else if (tab === "orders") {
    const res = await attempt(() => api("GET", "/api/admin/orders"));
    if (!res) return;
    // The list endpoint has no items; fetch each order's items for display.
    const full = await Promise.all(res.data.map((o) => api("GET", `/api/orders/${o.id}`).then((r) => ({ ...o, items: r.data.items })).catch(() => o)));
    body.innerHTML = full.length ? full.map((o) => orderCard(o, { admin: true })).join("") : '<div class="empty">No orders yet.</div>';
  } else if (tab === "users") {
    const res = await attempt(() => api("GET", "/api/admin/users"));
    if (!res) return;
    body.innerHTML = `<div class="panel"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th class="num">Orders</th></tr></thead>
      <tbody>${res.data.map((u) => `<tr><td>${u.id}</td><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${u.role}</td><td class="num">${u.orders}</td></tr>`).join("")}</tbody></table></div></div>`;
  }
}

function openBookForm(id) {
  const b = id === "new" ? {} : booksCache.get(Number(id)) || {};
  const v = (k) => esc(b[k] ?? "");
  openModal(`
    <h2>${id === "new" ? "Add book" : "Edit book"}</h2>
    <form data-form="book" data-id="${id}" novalidate>
      <div class="field"><label>Title</label><input name="title" value="${v("title")}" /></div>
      <div class="row"><div class="field"><label>Author</label><input name="author" value="${v("author")}" /></div>
        <div class="field"><label>Category</label><input name="category" value="${v("category")}" /></div></div>
      <div class="row"><div class="field"><label>Price (₹)</label><input name="price" type="number" min="1" value="${v("price")}" /></div>
        <div class="field"><label>Stock</label><input name="stock" type="number" min="0" value="${v("stock")}" /></div></div>
      <div class="row"><div class="field"><label>Year</label><input name="year" type="number" value="${v("year")}" /></div>
        <div class="field"><label>Rating (0-5)</label><input name="rating" type="number" min="0" max="5" step="0.1" value="${v("rating")}" /></div></div>
      <div class="field"><label>Description</label><textarea name="description" rows="3">${v("description")}</textarea></div>
      <p class="form-error" id="form-error"></p>
      <button class="btn block" type="submit">${id === "new" ? "Add book" : "Save changes"}</button>
    </form>`);
}

async function submitBook(form) {
  const body = {};
  for (const [k, v] of new FormData(form)) if (v !== "") body[k] = v;
  const id = form.dataset.id;
  try {
    if (id === "new") await api("POST", "/api/books", body);
    else await api("PUT", `/api/books/${id}`, body);
    closeModal();
    toast(id === "new" ? "Book added" : "Book updated");
    renderAdmin();
  } catch (err) {
    $("form-error").textContent = err.message;
  }
}

/* ===================== Router ===================== */
function currentRoute() {
  const r = (location.hash.replace(/^#\/?/, "") || "home").split("?")[0];
  return ["home", "cart", "orders", "admin"].includes(r) ? r : "home";
}

function route() {
  const r = currentRoute();
  renderHeader();
  $("main-nav").classList.remove("open");
  $("menu-toggle").setAttribute("aria-expanded", "false");
  if (r === "home") renderShop();
  else if (r === "cart") renderCart();
  else if (r === "orders") renderOrders();
  else if (r === "admin") renderAdmin();
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);

/* ===================== Events (one delegated listener) ===================== */
document.addEventListener("click", async (e) => {
  const t = (sel) => e.target.closest(sel);
  let el;

  if ((el = t("[data-action]"))) {
    const a = el.dataset.action;
    if (a === "login" || a === "show-login") { e.preventDefault(); openAuthModal("login"); }
    else if (a === "show-register") { e.preventDefault(); openAuthModal("register"); }
    else if (a === "logout") logout();
    else if (a === "clear-cart") { const c = await attempt(() => api("DELETE", "/api/cart")); if (c) { state.cart = c; renderHeader(); renderCart(); } }
  } else if ((el = t("[data-demo]"))) {
    const [email, password] = el.dataset.demo.split("|");
    const form = modal.querySelector("form");
    form.email.value = email; form.password.value = password;
    submitAuth(form);
  } else if ((el = t("[data-add]"))) {
    addToCart(Number(el.dataset.add));
  } else if ((el = t("[data-open-book]"))) {
    openBook(Number(el.dataset.openBook));
  } else if ((el = t("[data-cat]"))) {
    state.shop.category = el.dataset.cat; state.shop.page = 1; renderShop();
  } else if ((el = t("[data-page]")) && !el.disabled) {
    state.shop.page = Number(el.dataset.page); renderShop(); window.scrollTo({ top: 0, behavior: "smooth" });
  } else if ((el = t("[data-qty]"))) {
    const [id, qty] = el.dataset.qty.split("|"); changeQty(Number(id), Number(qty));
  } else if ((el = t("[data-remove]"))) {
    changeQty(Number(el.dataset.remove), 0);
  } else if ((el = t("[data-cancel]"))) {
    if (confirm("Cancel this order?")) {
      const r = await attempt(() => api("PATCH", `/api/orders/${el.dataset.cancel}/cancel`));
      if (r) { toast("Order cancelled"); renderOrders(); }
    }
  } else if ((el = t("[data-admin-tab]"))) {
    state.adminTab = el.dataset.adminTab; renderAdmin();
  } else if ((el = t("[data-book-form]"))) {
    openBookForm(el.dataset.bookForm);
  } else if ((el = t("[data-delete-book]"))) {
    const b = booksCache.get(Number(el.dataset.deleteBook));
    if (confirm(`Delete "${b ? b.title : "this book"}"? Past orders are kept.`)) {
      const r = await attempt(() => api("DELETE", `/api/books/${el.dataset.deleteBook}`).then(() => true));
      if (r) { toast("Book deleted"); renderAdmin(); }
    }
  } else if (t("#menu-toggle")) {
    const open = $("main-nav").classList.toggle("open");
    $("menu-toggle").setAttribute("aria-expanded", String(open));
  }
});

document.addEventListener("submit", (e) => {
  const form = e.target.closest("form[data-form]");
  if (!form) return;
  e.preventDefault();
  const kind = form.dataset.form;
  if (kind === "login" || kind === "register") submitAuth(form);
  else if (kind === "checkout") placeOrder(form);
  else if (kind === "book") submitBook(form);
});

document.addEventListener("change", async (e) => {
  if (e.target.id === "shop-sort") { state.shop.sort = e.target.value; state.shop.page = 1; renderShop(); }
  else if (e.target.matches("[data-set-status]") && e.target.value) {
    const r = await attempt(() => api("PATCH", `/api/admin/orders/${e.target.dataset.setStatus}/status`, { status: e.target.value }));
    if (r) { toast("Order status updated"); renderAdmin(); }
  }
});

let searchTimer;
document.addEventListener("input", (e) => {
  if (e.target.id !== "shop-search") return;
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { state.shop.search = e.target.value.trim(); state.shop.page = 1; renderShop(); }, 300);
});

/* ===================== Start ===================== */
(async function init() {
  await loadSession();
  route();
})();
