const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL UNIQUE,
  password_hash TEXT    NOT NULL,
  role          TEXT    NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS books (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT    NOT NULL,
  author      TEXT    NOT NULL,
  category    TEXT    NOT NULL,
  year        INTEGER,
  price       REAL    NOT NULL CHECK (price > 0),
  stock       INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  rating      REAL    CHECK (rating IS NULL OR (rating >= 0 AND rating <= 5)),
  description TEXT,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_books_category ON books (category);
CREATE INDEX IF NOT EXISTS idx_books_title    ON books (title);

CREATE TABLE IF NOT EXISTS cart_items (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id  INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  book_id  INTEGER NOT NULL REFERENCES books (id) ON DELETE CASCADE,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  UNIQUE (user_id, book_id)
);

CREATE TABLE IF NOT EXISTS orders (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL REFERENCES users (id),
  total            REAL    NOT NULL,
  status           TEXT    NOT NULL DEFAULT 'placed'
                   CHECK (status IN ('placed', 'shipped', 'delivered', 'cancelled')),
  shipping_address TEXT    NOT NULL,
  created_at       TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders (user_id);

-- Title and price are copied at purchase time, so history stays correct
-- even if the book is edited or deleted later.
CREATE TABLE IF NOT EXISTS order_items (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
  book_id  INTEGER REFERENCES books (id) ON DELETE SET NULL,
  title    TEXT    NOT NULL,
  price    REAL    NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0)
);
`;

/** Opens (and creates, if needed) the SQLite database. Use ":memory:" for tests. */
function openDatabase(file) {
  if (file !== ":memory:") {
    fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  }
  const db = new Database(file);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.exec(SCHEMA);
  return db;
}

module.exports = { openDatabase };
