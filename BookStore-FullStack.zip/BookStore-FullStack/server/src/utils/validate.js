const { badRequest } = require("./httpError");

/**
 * Tiny validation helpers. Each one returns a cleaned value or pushes a message
 * into `errors`. Call `throwIfInvalid(errors)` at the end to send all problems at once.
 */

function string(errors, body, field, { min = 1, max = 200, required = true } = {}) {
  const raw = body[field];
  if (raw === undefined || raw === null || raw === "") {
    if (required) errors[field] = `${field} is required`;
    return undefined;
  }
  if (typeof raw !== "string") {
    errors[field] = `${field} must be text`;
    return undefined;
  }
  const value = raw.trim();
  if (value.length < min || value.length > max) {
    errors[field] = `${field} must be ${min}-${max} characters`;
    return undefined;
  }
  return value;
}

function number(errors, body, field, { min = -Infinity, max = Infinity, integer = false, required = true } = {}) {
  const raw = body[field];
  if (raw === undefined || raw === null || raw === "") {
    if (required) errors[field] = `${field} is required`;
    return undefined;
  }
  const value = typeof raw === "string" && raw.trim() !== "" ? Number(raw) : raw;
  if (typeof value !== "number" || !Number.isFinite(value)) {
    errors[field] = `${field} must be a number`;
    return undefined;
  }
  if (integer && !Number.isInteger(value)) {
    errors[field] = `${field} must be a whole number`;
    return undefined;
  }
  if (value < min || value > max) {
    errors[field] = `${field} must be between ${min} and ${max}`;
    return undefined;
  }
  return value;
}

function throwIfInvalid(errors) {
  if (Object.keys(errors).length > 0) {
    throw badRequest("Validation failed", errors);
  }
}

/** Parses a positive integer id from a URL parameter. */
function idParam(value, name = "id") {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) throw badRequest(`Invalid ${name}`);
  return n;
}

module.exports = { string, number, throwIfInvalid, idParam };
