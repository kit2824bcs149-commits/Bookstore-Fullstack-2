/** An error that carries an HTTP status code and is safe to show to the client. */
class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

const badRequest = (msg, details) => new HttpError(400, msg, details);
const unauthorized = (msg = "Authentication required") => new HttpError(401, msg);
const forbidden = (msg = "You do not have permission to do this") => new HttpError(403, msg);
const notFound = (msg = "Not found") => new HttpError(404, msg);
const conflict = (msg) => new HttpError(409, msg);

module.exports = { HttpError, badRequest, unauthorized, forbidden, notFound, conflict };
