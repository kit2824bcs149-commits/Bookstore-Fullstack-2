const jwt = require("jsonwebtoken");
const config = require("../config");
const { unauthorized, forbidden } = require("../utils/httpError");

function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, config.jwtSecret, {
    expiresIn: config.jwtExpiresIn,
  });
}

/** Requires a valid "Authorization: Bearer <token>" header and loads req.user. */
function authenticate(db) {
  const findUser = db.prepare("SELECT id, name, email, role FROM users WHERE id = ?");

  return (req, _res, next) => {
    const header = req.headers.authorization || "";
    const [scheme, token] = header.split(" ");
    if (scheme !== "Bearer" || !token) return next(unauthorized());

    let payload;
    try {
      payload = jwt.verify(token, config.jwtSecret);
    } catch {
      return next(unauthorized("Invalid or expired token"));
    }

    // Always re-check the database so deleted users / changed roles take effect immediately.
    const user = findUser.get(payload.sub);
    if (!user) return next(unauthorized("User no longer exists"));

    req.user = user;
    next();
  };
}

function requireAdmin(req, _res, next) {
  if (req.user?.role !== "admin") return next(forbidden("Admin access required"));
  next();
}

module.exports = { signToken, authenticate, requireAdmin };
