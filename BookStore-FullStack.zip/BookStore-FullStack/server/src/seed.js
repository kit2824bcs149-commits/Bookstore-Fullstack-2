const bcrypt = require("bcryptjs");
const config = require("./config");
const books = require("../data/books.seed.json");

/**
 * Adds the admin account, a demo customer and the sample books - only into an EMPTY database,
 * so running it twice never creates duplicates.
 */
function seedIfEmpty(db) {
  const usersCount = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
  const booksCount = db.prepare("SELECT COUNT(*) AS n FROM books").get().n;
  const added = { users: 0, books: 0 };

  db.transaction(() => {
    if (usersCount === 0) {
      const insertUser = db.prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)");
      insertUser.run("Store Admin", config.adminEmail.toLowerCase(), bcrypt.hashSync(config.adminPassword, 10), "admin");
      insertUser.run("Demo Student", "student@example.com", bcrypt.hashSync("Student@123", 10), "customer");
      added.users = 2;
    }
    if (booksCount === 0) {
      const insertBook = db.prepare(
        `INSERT INTO books (title, author, category, year, price, stock, rating, description)
         VALUES (@title, @author, @category, @year, @price, @stock, @rating, @description)`
      );
      for (const b of books) insertBook.run(b);
      added.books = books.length;
    }
  })();

  if (added.users || added.books) {
    console.log(`🌱 Seeded ${added.users} users and ${added.books} books.`);
    if (added.users) {
      console.log(`   Admin:    ${config.adminEmail} / ${config.adminPassword}`);
      console.log("   Customer: student@example.com / Student@123");
    }
  }
  return added;
}

module.exports = { seedIfEmpty };

// `npm run seed` runs this file directly
if (require.main === module) {
  const { openDatabase } = require("./db");
  const db = openDatabase(config.dbFile);
  const added = seedIfEmpty(db);
  if (!added.users && !added.books) console.log("Database already has data - nothing to seed.");
  db.close();
}
