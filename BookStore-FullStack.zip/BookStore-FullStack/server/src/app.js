const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const path = require("path");
const rateLimit = require("express-rate-limit");
const config = require("./config");
const { notFoundHandler, errorHandler } = require("./middleware/errorHandler");

/** Builds the Express app. The database is passed in so tests can use an in-memory one. */
function createApp(db) {
  const app = express();

  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        // Allow plain http://localhost during development (default would force https).
        directives: { "upgrade-insecure-requests": null },
      },
    })
  );
  app.use(cors({ origin: config.corsOrigin === "*" ? true : config.corsOrigin.split(",") }));
  app.use(express.json({ limit: "100kb" }));

  if (!config.isTest) {
    const logger = (req, res, next) => {
      const start = Date.now();
      res.on("finish", () => console.log(`${req.method} ${req.originalUrl} ${res.statusCode} - ${Date.now() - start}ms`));
      next();
    };
    app.use(logger);
  }

  // Slow down password guessing on login / register.
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: config.isTest ? 10000 : 30,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many attempts. Please try again in a few minutes." },
  });

  app.get("/api", (_req, res) => {
    res.json({
      name: "Online Book Store API",
      status: "running",
      endpoints: ["/api/auth", "/api/books", "/api/cart", "/api/orders", "/api/admin"],
    });
  });
  app.get("/api/health", (_req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

  app.use("/api/auth", authLimiter, require("./routes/auth")(db));
  app.use("/api/books", require("./routes/books")(db));
  app.use("/api/cart", require("./routes/cart")(db));
  app.use("/api/orders", require("./routes/orders")(db));
  app.use("/api/admin", require("./routes/admin")(db));

  // The website itself (public/ folder) is served at http://localhost:3000
  app.use(express.static(path.join(__dirname, "..", "public")));

  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
