require("dotenv").config();

const isTest = process.env.NODE_ENV === "test";
const isProd = process.env.NODE_ENV === "production";

if (isProd && !process.env.JWT_SECRET) {
  throw new Error("JWT_SECRET must be set in production.");
}

module.exports = {
  isTest,
  isProd,
  port: Number(process.env.PORT) || 3000,
  jwtSecret: process.env.JWT_SECRET || "dev-only-secret-change-me",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "7d",
  dbFile: process.env.DB_FILE || "./data/bookstore.db",
  corsOrigin: process.env.CORS_ORIGIN || "*",
  adminEmail: process.env.ADMIN_EMAIL || "admin@bookstore.com",
  adminPassword: process.env.ADMIN_PASSWORD || "Admin@123",
};
