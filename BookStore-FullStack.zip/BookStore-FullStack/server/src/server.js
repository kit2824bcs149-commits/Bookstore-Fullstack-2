const config = require("./config");
const { openDatabase } = require("./db");
const { createApp } = require("./app");
const { seedIfEmpty } = require("./seed");

const db = openDatabase(config.dbFile);
seedIfEmpty(db); // first run: add the admin account and sample books

const app = createApp(db);
const server = app.listen(config.port, () => {
  console.log(`📚 Book Store API running at http://localhost:${config.port}`);
  console.log(`   Database: ${config.dbFile}`);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
