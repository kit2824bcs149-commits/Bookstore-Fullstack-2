const express = require("express");
const bcrypt = require("bcryptjs");
const { signToken, authenticate } = require("../middleware/auth");
const { string, throwIfInvalid } = require("../utils/validate");
const { conflict, unauthorized, badRequest } = require("../utils/httpError");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
// A real bcrypt hash used to keep login timing similar when the email does not exist.
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 10);

module.exports = function authRoutes(db) {
  const router = express.Router();
  const auth = authenticate(db);

  const findByEmail = db.prepare("SELECT * FROM users WHERE email = ?");
  const insertUser = db.prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");

  // POST /api/auth/register  { name, email, password }
  router.post("/register", (req, res) => {
    const errors = {};
    const name = string(errors, req.body, "name", { min: 2, max: 60 });
    const email = string(errors, req.body, "email", { max: 120 })?.toLowerCase();
    const password = string(errors, req.body, "password", { min: 8, max: 72 });
    if (email && !EMAIL_RE.test(email)) errors.email = "email is not valid";
    throwIfInvalid(errors);

    if (findByEmail.get(email)) throw conflict("This email is already registered");

    const hash = bcrypt.hashSync(password, 10);
    const { lastInsertRowid } = insertUser.run(name, email, hash);
    const user = { id: Number(lastInsertRowid), name, email, role: "customer" };
    res.status(201).json({ user, token: signToken(user) });
  });

  // POST /api/auth/login  { email, password }
  router.post("/login", (req, res) => {
    const email = typeof req.body.email === "string" ? req.body.email.trim().toLowerCase() : "";
    const password = typeof req.body.password === "string" ? req.body.password : "";
    if (!email || !password) throw badRequest("email and password are required");

    const row = findByEmail.get(email);
    const ok = bcrypt.compareSync(password, row ? row.password_hash : DUMMY_HASH);
    if (!row || !ok) throw unauthorized("Invalid email or password");

    const user = { id: row.id, name: row.name, email: row.email, role: row.role };
    res.json({ user, token: signToken(user) });
  });

  // GET /api/auth/me
  router.get("/me", auth, (req, res) => {
    res.json({ user: req.user });
  });

  return router;
};
