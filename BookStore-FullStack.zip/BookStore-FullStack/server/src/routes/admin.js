const express = require("express");
const { authenticate, requireAdmin } = require("../middleware/auth");
const { idParam } = require("../utils/validate");
const { notFound, badRequest } = require("../utils/httpError");

const STATUSES = ["placed", "shipped", "delivered", "cancelled"];
// Which status changes are allowed (cancelling is handled so stock is restored).
const NEXT = { placed: ["shipped", "cancelled"], shipped: ["delivered"], delivered: [], cancelled: [] };

module.exports = function adminRoutes(db) {
  const router = express.Router();
  router.use(authenticate(db), requireAdmin);

  // GET /api/admin/stats
  router.get("/stats", (_req, res) => {
    const one = (sql) => db.prepare(sql).get();
    res.json({
      users: one("SELECT COUNT(*) AS n FROM users WHERE role = 'customer'").n,
      books: one("SELECT COUNT(*) AS n FROM books").n,
      outOfStock: one("SELECT COUNT(*) AS n FROM books WHERE stock = 0").n,
      orders: one("SELECT COUNT(*) AS n FROM orders").n,
      revenue: one("SELECT COALESCE(SUM(total), 0) AS n FROM orders WHERE status != 'cancelled'").n,
      ordersByStatus: db.prepare("SELECT status, COUNT(*) AS count FROM orders GROUP BY status").all(),
      topBooks: db
        .prepare(
          `SELECT title, SUM(quantity) AS sold FROM order_items oi
           JOIN orders o ON o.id = oi.order_id WHERE o.status != 'cancelled'
           GROUP BY title ORDER BY sold DESC LIMIT 5`
        )
        .all(),
    });
  });

  // GET /api/admin/orders?status=placed
  router.get("/orders", (req, res) => {
    const { status } = req.query;
    if (status && !STATUSES.includes(status)) throw badRequest(`status must be one of: ${STATUSES.join(", ")}`);
    const orders = db
      .prepare(
        `SELECT o.*, u.name AS customerName, u.email AS customerEmail FROM orders o
         JOIN users u ON u.id = o.user_id ${status ? "WHERE o.status = ?" : ""} ORDER BY o.id DESC`
      )
      .all(...(status ? [status] : []));
    res.json({ data: orders });
  });

  // PATCH /api/admin/orders/:id/status  { status }
  router.patch("/orders/:id/status", (req, res) => {
    const id = idParam(req.params.id);
    const { status } = req.body;
    if (!STATUSES.includes(status)) throw badRequest(`status must be one of: ${STATUSES.join(", ")}`);

    const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(id);
    if (!order) throw notFound("Order not found");
    if (!NEXT[order.status].includes(status)) {
      throw badRequest(`Cannot change an order from "${order.status}" to "${status}"`);
    }

    db.transaction(() => {
      if (status === "cancelled") {
        const items = db.prepare("SELECT book_id, quantity FROM order_items WHERE order_id = ? AND book_id IS NOT NULL").all(id);
        for (const it of items) db.prepare("UPDATE books SET stock = stock + ? WHERE id = ?").run(it.quantity, it.book_id);
      }
      db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, id);
    })();

    res.json({ data: db.prepare("SELECT * FROM orders WHERE id = ?").get(id) });
  });

  // GET /api/admin/users
  router.get("/users", (_req, res) => {
    res.json({
      data: db
        .prepare(
          `SELECT u.id, u.name, u.email, u.role, u.created_at AS createdAt,
                  (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS orders
           FROM users u ORDER BY u.id`
        )
        .all(),
    });
  });

  return router;
};
