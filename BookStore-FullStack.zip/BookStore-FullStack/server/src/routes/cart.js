const express = require("express");
const { authenticate } = require("../middleware/auth");
const { number, throwIfInvalid, idParam } = require("../utils/validate");
const { notFound, badRequest } = require("../utils/httpError");

module.exports = function cartRoutes(db) {
  const router = express.Router();
  router.use(authenticate(db));

  const getBook = db.prepare("SELECT id, title, price, stock FROM books WHERE id = ?");
  const getItem = db.prepare("SELECT * FROM cart_items WHERE user_id = ? AND book_id = ?");

  function readCart(userId) {
    const items = db
      .prepare(
        `SELECT c.book_id AS bookId, b.title, b.author, b.price, b.stock, c.quantity,
                (b.price * c.quantity) AS lineTotal
         FROM cart_items c JOIN books b ON b.id = c.book_id
         WHERE c.user_id = ? ORDER BY c.id`
      )
      .all(userId);
    const total = items.reduce((sum, i) => sum + i.lineTotal, 0);
    const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);
    return { items, itemCount, total };
  }

  // GET /api/cart
  router.get("/", (req, res) => res.json(readCart(req.user.id)));

  // POST /api/cart  { bookId, quantity }  - adds to existing quantity
  router.post("/", (req, res) => {
    const errors = {};
    const bookId = number(errors, req.body, "bookId", { min: 1, integer: true });
    const quantity = number(errors, req.body, "quantity", { min: 1, max: 20, integer: true, required: false }) ?? 1;
    throwIfInvalid(errors);

    const book = getBook.get(bookId);
    if (!book) throw notFound("Book not found");

    const existing = getItem.get(req.user.id, bookId);
    const newQty = (existing?.quantity ?? 0) + quantity;
    if (newQty > book.stock) {
      throw badRequest(`Only ${book.stock} copies of "${book.title}" are in stock`);
    }

    if (existing) {
      db.prepare("UPDATE cart_items SET quantity = ? WHERE id = ?").run(newQty, existing.id);
    } else {
      db.prepare("INSERT INTO cart_items (user_id, book_id, quantity) VALUES (?, ?, ?)").run(req.user.id, bookId, quantity);
    }
    res.status(201).json(readCart(req.user.id));
  });

  // PUT /api/cart/:bookId  { quantity }  - sets the exact quantity
  router.put("/:bookId", (req, res) => {
    const bookId = idParam(req.params.bookId, "bookId");
    const errors = {};
    const quantity = number(errors, req.body, "quantity", { min: 1, max: 20, integer: true });
    throwIfInvalid(errors);

    const item = getItem.get(req.user.id, bookId);
    if (!item) throw notFound("This book is not in your cart");
    const book = getBook.get(bookId);
    if (quantity > book.stock) throw badRequest(`Only ${book.stock} copies of "${book.title}" are in stock`);

    db.prepare("UPDATE cart_items SET quantity = ? WHERE id = ?").run(quantity, item.id);
    res.json(readCart(req.user.id));
  });

  // DELETE /api/cart/:bookId
  router.delete("/:bookId", (req, res) => {
    const { changes } = db
      .prepare("DELETE FROM cart_items WHERE user_id = ? AND book_id = ?")
      .run(req.user.id, idParam(req.params.bookId, "bookId"));
    if (!changes) throw notFound("This book is not in your cart");
    res.json(readCart(req.user.id));
  });

  // DELETE /api/cart  - empties the cart
  router.delete("/", (req, res) => {
    db.prepare("DELETE FROM cart_items WHERE user_id = ?").run(req.user.id);
    res.json(readCart(req.user.id));
  });

  return router;
};
