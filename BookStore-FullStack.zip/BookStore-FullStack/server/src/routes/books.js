const express = require("express");
const { authenticate, requireAdmin } = require("../middleware/auth");
const { string, number, throwIfInvalid, idParam } = require("../utils/validate");
const { notFound } = require("../utils/httpError");

// Whitelist: the client chooses a key, never raw SQL.
const SORTS = {
  newest: "id DESC",
  "title-asc": "title COLLATE NOCASE ASC",
  "title-desc": "title COLLATE NOCASE DESC",
  "price-asc": "price ASC",
  "price-desc": "price DESC",
  "rating-desc": "rating DESC",
  "year-desc": "year DESC",
  "year-asc": "year ASC",
};

function readBookBody(body, { partial = false } = {}) {
  const errors = {};
  const required = !partial;
  const data = {
    title: string(errors, body, "title", { max: 200, required }),
    author: string(errors, body, "author", { max: 120, required }),
    category: string(errors, body, "category", { max: 60, required }),
    year: number(errors, body, "year", { min: 1000, max: new Date().getFullYear() + 1, integer: true, required: false }),
    price: number(errors, body, "price", { min: 1, max: 100000, required }),
    stock: number(errors, body, "stock", { min: 0, max: 100000, integer: true, required: false }),
    rating: number(errors, body, "rating", { min: 0, max: 5, required: false }),
    description: string(errors, body, "description", { max: 2000, required: false }),
  };
  throwIfInvalid(errors);
  return data;
}

module.exports = function bookRoutes(db) {
  const router = express.Router();
  const auth = authenticate(db);

  // GET /api/books?search=&category=&minPrice=&maxPrice=&inStock=&sort=&page=&limit=
  router.get("/", (req, res) => {
    const { search, category, minPrice, maxPrice, inStock, sort = "newest" } = req.query;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 12));

    const where = [];
    const params = [];

    if (typeof search === "string" && search.trim()) {
      const like = `%${search.trim().replace(/[\\%_]/g, "\\$&")}%`;
      where.push("(title LIKE ? ESCAPE '\\' OR author LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\')");
      params.push(like, like, like);
    }
    if (typeof category === "string" && category.trim()) {
      where.push("category = ? COLLATE NOCASE");
      params.push(category.trim());
    }
    if (minPrice !== undefined && Number.isFinite(Number(minPrice))) {
      where.push("price >= ?");
      params.push(Number(minPrice));
    }
    if (maxPrice !== undefined && Number.isFinite(Number(maxPrice))) {
      where.push("price <= ?");
      params.push(Number(maxPrice));
    }
    if (inStock === "true") where.push("stock > 0");

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
    const orderSql = SORTS[sort] || SORTS.newest;

    const total = db.prepare(`SELECT COUNT(*) AS n FROM books ${whereSql}`).get(...params).n;
    const data = db
      .prepare(`SELECT * FROM books ${whereSql} ORDER BY ${orderSql}, id ASC LIMIT ? OFFSET ?`)
      .all(...params, limit, (page - 1) * limit);

    res.json({
      data,
      pagination: { page, limit, total, totalPages: Math.max(1, Math.ceil(total / limit)) },
    });
  });

  // GET /api/books/categories
  router.get("/categories", (_req, res) => {
    const rows = db
      .prepare("SELECT category AS name, COUNT(*) AS books FROM books GROUP BY category ORDER BY category")
      .all();
    res.json({ data: rows });
  });

  // GET /api/books/:id
  router.get("/:id", (req, res) => {
    const book = db.prepare("SELECT * FROM books WHERE id = ?").get(idParam(req.params.id));
    if (!book) throw notFound("Book not found");
    res.json({ data: book });
  });

  // POST /api/books  (admin)
  router.post("/", auth, requireAdmin, (req, res) => {
    const b = readBookBody(req.body);
    const { lastInsertRowid } = db
      .prepare(
        `INSERT INTO books (title, author, category, year, price, stock, rating, description)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(b.title, b.author, b.category, b.year ?? null, b.price, b.stock ?? 0, b.rating ?? null, b.description ?? null);
    const book = db.prepare("SELECT * FROM books WHERE id = ?").get(lastInsertRowid);
    res.status(201).json({ data: book });
  });

  // PUT /api/books/:id  (admin) - send only the fields you want to change
  router.put("/:id", auth, requireAdmin, (req, res) => {
    const id = idParam(req.params.id);
    const existing = db.prepare("SELECT * FROM books WHERE id = ?").get(id);
    if (!existing) throw notFound("Book not found");

    const changes = readBookBody(req.body, { partial: true });
    const merged = { ...existing };
    for (const [key, value] of Object.entries(changes)) {
      if (value !== undefined) merged[key] = value;
    }

    db.prepare(
      `UPDATE books SET title = ?, author = ?, category = ?, year = ?, price = ?,
         stock = ?, rating = ?, description = ? WHERE id = ?`
    ).run(merged.title, merged.author, merged.category, merged.year, merged.price,
          merged.stock, merged.rating, merged.description, id);

    res.json({ data: db.prepare("SELECT * FROM books WHERE id = ?").get(id) });
  });

  // DELETE /api/books/:id  (admin)
  router.delete("/:id", auth, requireAdmin, (req, res) => {
    const { changes } = db.prepare("DELETE FROM books WHERE id = ?").run(idParam(req.params.id));
    if (!changes) throw notFound("Book not found");
    res.status(204).end();
  });

  return router;
};
