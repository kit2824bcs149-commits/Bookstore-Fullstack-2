const express = require("express");
const { authenticate } = require("../middleware/auth");
const { string, throwIfInvalid, idParam } = require("../utils/validate");
const { notFound, badRequest, forbidden } = require("../utils/httpError");

module.exports = function orderRoutes(db) {
  const router = express.Router();
  router.use(authenticate(db));

  function loadOrder(id) {
    const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(id);
    if (!order) return null;
    order.items = db
      .prepare("SELECT book_id AS bookId, title, price, quantity, (price * quantity) AS lineTotal FROM order_items WHERE order_id = ?")
      .all(id);
    return order;
  }

  // The whole checkout runs in ONE transaction: either everything succeeds or nothing changes.
  const checkout = db.transaction((userId, shippingAddress) => {
    const cart = db
      .prepare(
        `SELECT c.book_id, c.quantity, b.title, b.price, b.stock
         FROM cart_items c JOIN books b ON b.id = c.book_id WHERE c.user_id = ?`
      )
      .all(userId);
    if (cart.length === 0) throw badRequest("Your cart is empty");

    const reduceStock = db.prepare("UPDATE books SET stock = stock - ? WHERE id = ? AND stock >= ?");
    for (const item of cart) {
      // The "stock >= ?" guard makes overselling impossible, even with simultaneous requests.
      if (reduceStock.run(item.quantity, item.book_id, item.quantity).changes === 0) {
        throw badRequest(`Not enough stock for "${item.title}" (available: ${item.stock})`);
      }
    }

    const total = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
    const { lastInsertRowid: orderId } = db
      .prepare("INSERT INTO orders (user_id, total, shipping_address) VALUES (?, ?, ?)")
      .run(userId, total, shippingAddress);

    const insertItem = db.prepare("INSERT INTO order_items (order_id, book_id, title, price, quantity) VALUES (?, ?, ?, ?, ?)");
    for (const item of cart) insertItem.run(orderId, item.book_id, item.title, item.price, item.quantity);

    db.prepare("DELETE FROM cart_items WHERE user_id = ?").run(userId);
    return Number(orderId);
  });

  const cancel = db.transaction((orderId) => {
    const items = db.prepare("SELECT book_id, quantity FROM order_items WHERE order_id = ? AND book_id IS NOT NULL").all(orderId);
    const restock = db.prepare("UPDATE books SET stock = stock + ? WHERE id = ?");
    for (const item of items) restock.run(item.quantity, item.book_id);
    db.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?").run(orderId);
  });

  // POST /api/orders  { shippingAddress }  - turns the cart into an order
  router.post("/", (req, res) => {
    const errors = {};
    const address = string(errors, req.body, "shippingAddress", { min: 10, max: 300 });
    throwIfInvalid(errors);
    const orderId = checkout(req.user.id, address);
    res.status(201).json({ data: loadOrder(orderId) });
  });

  // GET /api/orders  - my orders
  router.get("/", (req, res) => {
    const rows = db.prepare("SELECT id FROM orders WHERE user_id = ? ORDER BY id DESC").all(req.user.id);
    res.json({ data: rows.map((r) => loadOrder(r.id)) });
  });

  // GET /api/orders/:id  - my order (admins can view any)
  router.get("/:id", (req, res) => {
    const order = loadOrder(idParam(req.params.id));
    if (!order) throw notFound("Order not found");
    if (order.user_id !== req.user.id && req.user.role !== "admin") throw forbidden();
    res.json({ data: order });
  });

  // PATCH /api/orders/:id/cancel  - only while the order is still "placed"
  router.patch("/:id/cancel", (req, res) => {
    const id = idParam(req.params.id);
    const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(id);
    if (!order) throw notFound("Order not found");
    if (order.user_id !== req.user.id) throw forbidden();
    if (order.status !== "placed") throw badRequest(`A ${order.status} order cannot be cancelled`);
    cancel(id);
    res.json({ data: loadOrder(id) });
  });

  return router;
};
