# 📚 Online Book Store – Backend System

A complete **REST API backend** for an online book store, built with **Node.js, Express and SQLite**.
Includes user registration/login (JWT), a book catalog with search/filter/sort/pagination, a shopping cart,
order checkout with stock control, and an admin panel API.

> Project for *Modern Web Programming* – Online Book Store Backend System.
>
> It comes with a **ready-made website (the store front)** that talks to the backend, so you can open and use everything in your browser – no extra tools needed.

## 🖥️ What you can do in the browser
| Page | What it shows |
|------|---------------|
| **Shop** (`/`) | Search, category chips, sort, pagination, book details popup, add to cart |
| **Login / Register** | Popup with demo-account buttons (Customer / Admin) |
| **Cart** | Change quantity, remove, total, shipping address, **Place order** |
| **My Orders** | Order history with status, **Cancel order** while it is still "placed" |
| **Admin** (admin login only) | Dashboard numbers, add / edit / delete books, change order status, user list |

## ✨ Features
| Area | What it does |
|------|--------------|
| **Authentication** | Register, login, JWT tokens, passwords hashed with bcrypt, role-based access (`customer` / `admin`) |
| **Books** | Public list with search, category, price range, in-stock filter, 8 sort options, pagination. Admin can add / edit / delete |
| **Cart** | Add, change quantity, remove, empty. Quantity is checked against stock |
| **Orders** | Checkout in one database **transaction** (no overselling), order history, cancel (stock is restored) |
| **Admin** | Dashboard statistics, view all orders, change order status (placed → shipped → delivered), list users |
| **Security** | Helmet headers, CORS, rate limit on login, parameterised SQL (no SQL injection), input validation, JSON size limit |
| **Quality** | 15 automated tests, central error handling, clean folder structure |

## 🧰 Tech stack
| Part | Technology |
|------|-----------|
| Runtime | Node.js (18 or newer) |
| Web framework | Express 4 |
| Database | SQLite via `better-sqlite3` (a single file – **no database server to install**) |
| Auth | `jsonwebtoken` + `bcryptjs` |
| Security | `helmet`, `cors`, `express-rate-limit` |
| Testing | Node's built-in test runner (`node:test`) |

## ▶️ How to run

### Easiest way (Windows): double-click `start.bat`
It installs the packages the first time, starts the server and opens the shop in your browser at **http://localhost:3000**.
(Mac/Linux: run `./start.sh`.) Keep the black window open while you use the shop; close it to stop the server.

### Or from Visual Studio Code

**1. Install Node.js** (LTS) from <https://nodejs.org> if you don't have it. Check with `node -v`.

**2. Open the folder** `server` in VS Code (File → Open Folder), then open the terminal (**Ctrl + `**).

**3. Install and start:**
```bash
npm install
npm start
```
You should see:
```
🌱 Seeded 2 users and 26 books.
📚 Book Store API running at http://localhost:3000
```
Open <http://localhost:3000> in your browser – the full book store website appears (shop, cart, orders, admin panel).
The raw API is at <http://localhost:3000/api/books>.

> **Double-clicking `public/index.html` also works** as long as the server is running – the page then talks to `http://localhost:3000`.
> The backend itself must always be running (that is what makes it a *backend*).

The first start creates `data/bookstore.db` and fills it with an admin account, a demo customer and 26 books.

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@bookstore.com` | `Admin@123` |
| Customer | `student@example.com` | `Student@123` |

**4. Try every endpoint inside VS Code:** install the **REST Client** extension, open `requests.http`
and click **Send Request** above any request (it logs in and reuses the token automatically).

**Troubleshooting**
- *"Cannot reach the server"* in the browser → the server is not running. Start it with `npm start` or `start.bat`.
- *Port 3000 already in use* → close the other program, or set `PORT=3001` in a `.env` file (copy `.env.example`).
- Reset all data → stop the server and delete `data/bookstore.db`.

**Other commands**
```bash
npm run dev     # auto-restart when you edit code
npm test        # run the 15 automated tests
npm run seed    # add sample data to an empty database
```
To reset everything, stop the server and delete `data/bookstore.db`.

> **If `npm install` fails on `better-sqlite3`** (rare, on very new Node versions): install the Node.js **LTS** version, or install the
> "Desktop development with C++" tools from the Visual Studio Installer, then run `npm install` again.

**Visual Studio (full IDE):** File → Open → Folder → choose `server`, then run `npm start` in the terminal
(Visual Studio's *Node.js development* workload is needed for the debugger).

## 🔌 API reference
Send the token as `Authorization: Bearer <token>`. All bodies are JSON.

### Auth
| Method | Endpoint | Access | Body |
|--------|----------|--------|------|
| POST | `/api/auth/register` | public | `name`, `email`, `password` (min 8) |
| POST | `/api/auth/login` | public | `email`, `password` |
| GET | `/api/auth/me` | logged in | – |

### Books
| Method | Endpoint | Access | Notes |
|--------|----------|--------|-------|
| GET | `/api/books` | public | Query: `search`, `category`, `minPrice`, `maxPrice`, `inStock=true`, `sort`, `page`, `limit` |
| GET | `/api/books/categories` | public | Categories with counts |
| GET | `/api/books/:id` | public | |
| POST | `/api/books` | **admin** | `title`, `author`, `category`, `price` (+ `year`, `stock`, `rating`, `description`) |
| PUT | `/api/books/:id` | **admin** | Any of the fields above |
| DELETE | `/api/books/:id` | **admin** | |

`sort` values: `newest`, `title-asc`, `title-desc`, `price-asc`, `price-desc`, `rating-desc`, `year-desc`, `year-asc`

### Cart (logged in)
| Method | Endpoint | Body |
|--------|----------|------|
| GET | `/api/cart` | – |
| POST | `/api/cart` | `bookId`, `quantity` (adds to existing) |
| PUT | `/api/cart/:bookId` | `quantity` (sets exact value) |
| DELETE | `/api/cart/:bookId` | – |
| DELETE | `/api/cart` | – (empties cart) |

### Orders (logged in)
| Method | Endpoint | Notes |
|--------|----------|-------|
| POST | `/api/orders` | Body: `shippingAddress`. Converts the cart into an order |
| GET | `/api/orders` | My orders |
| GET | `/api/orders/:id` | My order (admin can open any) |
| PATCH | `/api/orders/:id/cancel` | Only while status is `placed` |

### Admin
| Method | Endpoint | Notes |
|--------|----------|-------|
| GET | `/api/admin/stats` | Users, books, out-of-stock, orders, revenue, top sellers |
| GET | `/api/admin/orders` | Optional `?status=` |
| PATCH | `/api/admin/orders/:id/status` | Body: `status` (`placed→shipped→delivered`, or `cancelled`) |
| GET | `/api/admin/users` | |

### Response format
- Success: `{ "data": ... }` (lists also include `pagination`).
- Error: `{ "error": "message" }`, and for validation `{ "error": "Validation failed", "details": { "email": "..." } }`.
- Status codes: `200/201` ok · `400` bad input · `401` not logged in · `403` not allowed · `404` not found · `409` already exists · `429` too many attempts.

## 🗄️ Database design
```
users ─────< cart_items >───── books
  │                              │
  └───< orders ──< order_items >─┘  (book_id set to NULL if the book is deleted)
```
| Table | Main columns |
|-------|--------------|
| `users` | id, name, email (unique), password_hash, role |
| `books` | id, title, author, category, year, price, stock, rating, description |
| `cart_items` | user_id, book_id, quantity (unique per user + book) |
| `orders` | id, user_id, total, status, shipping_address, created_at |
| `order_items` | order_id, book_id, **title**, **price**, quantity (copied at purchase time so old orders never change) |

## 📁 Folder structure
```
server/
├── package.json
├── .env.example            # settings template (optional: copy to .env)
├── requests.http           # ready-made API requests for VS Code
├── start.bat / start.sh    # one-click start (installs + opens the browser)
├── public/                 # the website (served by Express at /)
│   ├── index.html
│   ├── css/style.css
│   └── js/ api.js (calls the backend) · app.js (pages, cart, admin)
├── data/
│   └── books.seed.json     # 26 sample books
├── src/
│   ├── server.js           # starts the server
│   ├── app.js              # Express setup + routes
│   ├── config.js           # environment settings
│   ├── db.js               # SQLite connection + table definitions
│   ├── seed.js             # first-run sample data
│   ├── middleware/         # auth (JWT, roles), error handler
│   ├── routes/             # auth, books, cart, orders, admin
│   └── utils/              # validation helpers, HttpError
└── test/
    └── api.test.js         # 15 automated tests
```

## 🧠 Concepts used (useful for viva)
- **REST API design** – resources, HTTP verbs, status codes, stateless requests
- **MVC-style separation** – routes / middleware / database layers
- **JWT authentication** and **role-based authorisation** (customer vs admin)
- **Password hashing** with bcrypt (passwords are never stored in plain text)
- **Relational database** – primary/foreign keys, `UNIQUE`, `CHECK` constraints, indexes, `ON DELETE CASCADE / SET NULL`
- **Transactions** – checkout either fully succeeds or changes nothing (ACID)
- **Prepared statements** – protects against SQL injection
- **Middleware** – authentication, validation, error handling, rate limiting
- **Environment variables** with `.env`
- **Automated testing** – 15 tests covering auth, permissions, cart, checkout, cancellation, rollback

## 🔮 Ideas to extend
Connect the *PageTurner* frontend using `fetch("http://localhost:3000/api/books")`, add book reviews, payment gateway (Razorpay),
email confirmation, image upload for covers, or switch SQLite to MySQL / MongoDB.

## 📄 License
MIT
