process.env.NODE_ENV = "test";

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { openDatabase } = require("../src/db");
const { createApp } = require("../src/app");
const { seedIfEmpty } = require("../src/seed");

let server, base, db;

before(async () => {
  db = openDatabase(":memory:");
  seedIfEmpty(db);
  server = createApp(db).listen(0);
  await new Promise((resolve) => server.once("listening", resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  server.close();
  db.close();
});

async function api(method, path, { body, token } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: {
      ...(body && { "Content-Type": "application/json" }),
      ...(token && { Authorization: `Bearer ${token}` }),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : null };
}

const login = async (email, password) => (await api("POST", "/api/auth/login", { body: { email, password } })).body.token;
const stockOf = (id) => db.prepare("SELECT stock FROM books WHERE id = ?").get(id).stock;

/* ---------------- Auth ---------------- */

test("register creates a customer and returns a token; duplicate email is rejected", async () => {
  const body = { name: "Asha K", email: "Asha@Example.com", password: "password123" };
  const first = await api("POST", "/api/auth/register", { body });
  assert.equal(first.status, 201);
  assert.equal(first.body.user.role, "customer");
  assert.equal(first.body.user.email, "asha@example.com"); // normalised to lower case
  assert.ok(first.body.token);
  assert.equal(first.body.user.password_hash, undefined);

  const again = await api("POST", "/api/auth/register", { body });
  assert.equal(again.status, 409);
});

test("register validates input and cannot choose its own role", async () => {
  const bad = await api("POST", "/api/auth/register", { body: { name: "A", email: "nope", password: "123" } });
  assert.equal(bad.status, 400);
  assert.ok(bad.body.details.name && bad.body.details.email && bad.body.details.password);

  const sneaky = await api("POST", "/api/auth/register", {
    body: { name: "Mallory", email: "mal@example.com", password: "password123", role: "admin" },
  });
  assert.equal(sneaky.body.user.role, "customer");
});

test("login works, wrong password fails, /me needs a token", async () => {
  const ok = await api("POST", "/api/auth/login", { body: { email: "student@example.com", password: "Student@123" } });
  assert.equal(ok.status, 200);
  const me = await api("GET", "/api/auth/me", { token: ok.body.token });
  assert.equal(me.body.user.email, "student@example.com");

  const wrong = await api("POST", "/api/auth/login", { body: { email: "student@example.com", password: "wrong" } });
  assert.equal(wrong.status, 401);
  const unknown = await api("POST", "/api/auth/login", { body: { email: "ghost@example.com", password: "whatever1" } });
  assert.equal(unknown.status, 401);
  assert.equal(wrong.body.error, unknown.body.error); // does not reveal which emails exist

  assert.equal((await api("GET", "/api/auth/me")).status, 401);
  assert.equal((await api("GET", "/api/auth/me", { token: "garbage" })).status, 401);
});

/* ---------------- Books ---------------- */

test("books: list with pagination, search, filter and sort", async () => {
  const page1 = await api("GET", "/api/books?limit=10");
  assert.equal(page1.status, 200);
  assert.equal(page1.body.data.length, 10);
  assert.equal(page1.body.pagination.total, 26);
  assert.equal(page1.body.pagination.totalPages, 3);

  const search = await api("GET", "/api/books?search=kalam");
  assert.equal(search.body.data.length, 1);
  assert.equal(search.body.data[0].title, "Wings of Fire");

  const tech = await api("GET", "/api/books?category=technology");
  assert.ok(tech.body.data.length >= 5);
  assert.ok(tech.body.data.every((b) => b.category === "Technology"));

  const cheap = await api("GET", "/api/books?sort=price-asc&limit=1");
  assert.equal(cheap.body.data[0].title, "Gitanjali");

  const range = await api("GET", "/api/books?minPrice=300&maxPrice=400&limit=50");
  assert.ok(range.body.data.every((b) => b.price >= 300 && b.price <= 400));

  const cats = await api("GET", "/api/books/categories");
  assert.ok(cats.body.data.some((c) => c.name === "Fantasy" && c.books === 2));
});

test("books: search treats % and _ as plain characters (no SQL wildcard surprises)", async () => {
  const res = await api("GET", "/api/books?search=%25");
  assert.equal(res.body.data.length, 0);
  const inj = await api("GET", "/api/books?search=" + encodeURIComponent("'; DROP TABLE books;--"));
  assert.equal(inj.status, 200);
  assert.equal((await api("GET", "/api/books")).body.pagination.total, 26);
});

test("books: single book, 404 and bad id", async () => {
  assert.equal((await api("GET", "/api/books/1")).body.data.title, "Wings of Fire");
  assert.equal((await api("GET", "/api/books/99999")).status, 404);
  assert.equal((await api("GET", "/api/books/abc")).status, 400);
});

test("books: only admins can create, update and delete", async () => {
  const student = await login("student@example.com", "Student@123");
  const admin = await login("admin@bookstore.com", "Admin@123");
  const newBook = { title: "Test Driven Node", author: "Some Author", category: "Technology", price: 499, stock: 5 };

  assert.equal((await api("POST", "/api/books", { body: newBook })).status, 401);
  assert.equal((await api("POST", "/api/books", { body: newBook, token: student })).status, 403);

  const created = await api("POST", "/api/books", { body: newBook, token: admin });
  assert.equal(created.status, 201);
  const id = created.body.data.id;

  const invalid = await api("POST", "/api/books", { body: { title: "", price: -5 }, token: admin });
  assert.equal(invalid.status, 400);

  const updated = await api("PUT", `/api/books/${id}`, { body: { price: 550 }, token: admin });
  assert.equal(updated.body.data.price, 550);
  assert.equal(updated.body.data.title, "Test Driven Node"); // untouched fields are kept

  assert.equal((await api("DELETE", `/api/books/${id}`, { token: student })).status, 403);
  assert.equal((await api("DELETE", `/api/books/${id}`, { token: admin })).status, 204);
  assert.equal((await api("GET", `/api/books/${id}`)).status, 404);
});

/* ---------------- Cart + Orders ---------------- */

test("cart requires login, merges quantities and respects stock", async () => {
  assert.equal((await api("GET", "/api/cart")).status, 401);
  const token = (await api("POST", "/api/auth/register", { body: { name: "Cart User", email: "cart@example.com", password: "password123" } })).body.token;

  await api("POST", "/api/cart", { token, body: { bookId: 2, quantity: 1 } });
  const merged = await api("POST", "/api/cart", { token, body: { bookId: 2, quantity: 2 } });
  assert.equal(merged.body.items.length, 1);
  assert.equal(merged.body.items[0].quantity, 3);
  assert.equal(merged.body.total, 3 * 350);

  const tooMany = await api("POST", "/api/cart", { token, body: { bookId: 2, quantity: 20 } });
  assert.equal(tooMany.status, 400);
  assert.equal((await api("POST", "/api/cart", { token, body: { bookId: 9999 } })).status, 404);
  assert.equal((await api("POST", "/api/cart", { token, body: { bookId: 2, quantity: 0 } })).status, 400);

  const set = await api("PUT", "/api/cart/2", { token, body: { quantity: 1 } });
  assert.equal(set.body.itemCount, 1);
  const removed = await api("DELETE", "/api/cart/2", { token });
  assert.equal(removed.body.items.length, 0);
});

test("checkout: creates order, reduces stock, empties cart; cancel restores stock", async () => {
  const token = await login("student@example.com", "Student@123");
  const before = stockOf(3);

  await api("POST", "/api/cart", { token, body: { bookId: 3, quantity: 2 } });
  await api("POST", "/api/cart", { token, body: { bookId: 4, quantity: 1 } });

  const short = await api("POST", "/api/orders", { token, body: { shippingAddress: "x" } });
  assert.equal(short.status, 400);

  const order = await api("POST", "/api/orders", { token, body: { shippingAddress: "12 Gandhi Road, Coimbatore 641001" } });
  assert.equal(order.status, 201);
  assert.equal(order.body.data.status, "placed");
  assert.equal(order.body.data.total, 2 * 499 + 899);
  assert.equal(order.body.data.items.length, 2);
  assert.equal(stockOf(3), before - 2);
  assert.equal((await api("GET", "/api/cart", { token })).body.items.length, 0);

  const empty = await api("POST", "/api/orders", { token, body: { shippingAddress: "12 Gandhi Road, Coimbatore" } });
  assert.equal(empty.body.error, "Your cart is empty");

  const cancelled = await api("PATCH", `/api/orders/${order.body.data.id}/cancel`, { token });
  assert.equal(cancelled.body.data.status, "cancelled");
  assert.equal(stockOf(3), before);

  const twice = await api("PATCH", `/api/orders/${order.body.data.id}/cancel`, { token });
  assert.equal(twice.status, 400);
});

test("checkout: stock changes after carting cause a clean failure with nothing changed", async () => {
  const admin = await login("admin@bookstore.com", "Admin@123");
  const created = await api("POST", "/api/books", { token: admin, body: { title: "Last Copy", author: "X Y", category: "Fiction", price: 100, stock: 1 } });
  const bookId = created.body.data.id;

  const token = await login("student@example.com", "Student@123");
  await api("POST", "/api/cart", { token, body: { bookId: 5, quantity: 1 } });
  await api("POST", "/api/cart", { token, body: { bookId, quantity: 1 } });
  const stock5 = stockOf(5);

  // Someone else buys the last copy / admin lowers the stock before checkout.
  await api("PUT", `/api/books/${bookId}`, { token: admin, body: { stock: 0 } });

  const res = await api("POST", "/api/orders", { token, body: { shippingAddress: "12 Gandhi Road, Coimbatore" } });
  assert.equal(res.status, 400);
  assert.match(res.body.error, /Not enough stock/);
  assert.equal(stockOf(5), stock5);                                   // rolled back
  assert.equal((await api("GET", "/api/cart", { token })).body.items.length, 2); // cart kept
  await api("DELETE", "/api/cart", { token });
});

test("orders are private to their owner, but admins can see everything", async () => {
  const student = await login("student@example.com", "Student@123");
  const other = (await api("POST", "/api/auth/register", { body: { name: "Other User", email: "other@example.com", password: "password123" } })).body.token;
  const admin = await login("admin@bookstore.com", "Admin@123");

  await api("POST", "/api/cart", { token: student, body: { bookId: 6 } });
  const order = (await api("POST", "/api/orders", { token: student, body: { shippingAddress: "12 Gandhi Road, Coimbatore" } })).body.data;

  assert.equal((await api("GET", `/api/orders/${order.id}`, { token: other })).status, 403);
  assert.equal((await api("PATCH", `/api/orders/${order.id}/cancel`, { token: other })).status, 403);
  assert.equal((await api("GET", `/api/orders/${order.id}`, { token: admin })).status, 200);
  assert.equal((await api("GET", "/api/orders", { token: other })).body.data.length, 0);
  assert.ok((await api("GET", "/api/orders", { token: student })).body.data.length >= 1);
});

/* ---------------- Admin ---------------- */

test("admin: manage order status with valid transitions only; stats and users", async () => {
  const student = await login("student@example.com", "Student@123");
  const admin = await login("admin@bookstore.com", "Admin@123");

  await api("POST", "/api/cart", { token: student, body: { bookId: 7, quantity: 2 } });
  const order = (await api("POST", "/api/orders", { token: student, body: { shippingAddress: "12 Gandhi Road, Coimbatore" } })).body.data;

  assert.equal((await api("PATCH", `/api/admin/orders/${order.id}/status`, { token: student, body: { status: "shipped" } })).status, 403);
  assert.equal((await api("PATCH", `/api/admin/orders/${order.id}/status`, { token: admin, body: { status: "delivered" } })).status, 400); // must ship first
  assert.equal((await api("PATCH", `/api/admin/orders/${order.id}/status`, { token: admin, body: { status: "bogus" } })).status, 400);

  const shipped = await api("PATCH", `/api/admin/orders/${order.id}/status`, { token: admin, body: { status: "shipped" } });
  assert.equal(shipped.body.data.status, "shipped");
  assert.equal((await api("PATCH", `/api/orders/${order.id}/cancel`, { token: student })).status, 400); // too late to cancel
  assert.equal((await api("PATCH", `/api/admin/orders/${order.id}/status`, { token: admin, body: { status: "delivered" } })).body.data.status, "delivered");

  const stats = await api("GET", "/api/admin/stats", { token: admin });
  assert.equal(stats.status, 200);
  assert.ok(stats.body.revenue > 0 && stats.body.books >= 26);
  assert.ok(Array.isArray(stats.body.topBooks));

  const users = await api("GET", "/api/admin/users", { token: admin });
  assert.ok(users.body.data.every((u) => u.password_hash === undefined));
  assert.equal((await api("GET", "/api/admin/users", { token: student })).status, 403);
  assert.equal((await api("GET", "/api/admin/orders?status=delivered", { token: admin })).body.data.length >= 1, true);
});

test("deleting a book keeps past orders readable", async () => {
  const admin = await login("admin@bookstore.com", "Admin@123");
  const student = await login("student@example.com", "Student@123");
  const book = (await api("POST", "/api/books", { token: admin, body: { title: "Temporary Book", author: "A B", category: "Fiction", price: 120, stock: 3 } })).body.data;

  await api("POST", "/api/cart", { token: student, body: { bookId: book.id } });
  const order = (await api("POST", "/api/orders", { token: student, body: { shippingAddress: "12 Gandhi Road, Coimbatore" } })).body.data;

  assert.equal((await api("DELETE", `/api/books/${book.id}`, { token: admin })).status, 204);
  const after = await api("GET", `/api/orders/${order.id}`, { token: student });
  assert.equal(after.body.data.items[0].title, "Temporary Book");
});

/* ---------------- General ---------------- */

test("website: the store front is served at / and the API info at /api", async () => {
  const page = await fetch(base + "/");
  assert.equal(page.status, 200);
  assert.match(page.headers.get("content-type"), /text\/html/);
  assert.match(await page.text(), /PageTurner/);
  assert.equal((await fetch(base + "/js/app.js")).status, 200);
  assert.equal((await api("GET", "/api")).body.status, "running");
});

test("errors: bad JSON, unknown route, health check", async () => {
  const res = await fetch(base + "/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{not json" });
  assert.equal(res.status, 400);
  assert.equal((await api("GET", "/api/nope")).status, 404);
  assert.equal((await api("GET", "/api/health")).body.status, "ok");
});
