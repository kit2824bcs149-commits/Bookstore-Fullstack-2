@echo off
title PageTurner Book Store
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto nonode

if exist node_modules goto run
echo Installing packages (first time only, needs internet)...
call npm install
if errorlevel 1 goto fail

:run
echo.
echo Starting the server... your browser will open at http://localhost:3000
echo Keep this window open while using the shop. Close it to stop the server.
echo.
start "" cmd /c "timeout /t 3 >nul & start http://localhost:3000"
call npm start
pause
goto :eof

:nonode
echo Node.js is not installed. Download the LTS version from https://nodejs.org , install it, then double-click start.bat again.
pause
goto :eof

:fail
echo npm install failed. Check your internet connection and read the Troubleshooting part of README.md
pause
