"use strict";
/*
 * REAL BACKEND CONNECTOR
 * ----------------------
 * Talks to the Node.js + Express + SQLite server in the "server" folder using fetch().
 * It exposes exactly the same methods as api-local.js, so the screens work with both.
 */
(function (global) {
  const ApiError = global.LocalApi.ApiError;

  function create(baseUrl, onLog) {
    const base = String(baseUrl || "http://localhost:3000").replace(/\/+$/, "");
    const api = { mode: "remote", label: "Node server", baseUrl: base, token: null };

    async function request(method, path, body) {
      const t0 = performance.now();
      let res;
      try {
        res = await fetch(base + path, {
          method,
          headers: {
            ...(body !== undefined && { "Content-Type": "application/json" }),
            ...(api.token && { Authorization: "Bearer " + api.token }),
          },
          body: body !== undefined ? JSON.stringify(body) : undefined,
        });
      } catch {
        onLog && onLog({ method, path, status: 0, ms: Math.round(performance.now() - t0) });
        throw new ApiError(0, `Cannot reach the server at ${base}. Start it with "npm start" inside the server folder.`);
      }
      onLog && onLog({ method, path, status: res.status, ms: Math.round(performance.now() - t0) });

      const text = await res.text();
      let json = null;
      try { json = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
      if (!res.ok) throw new ApiError(res.status, (json && json.error) || `Request failed (${res.status})`, json && json.details);
      return json || {};
    }

    const qs = (q) => {
      const p = Object.entries(q || {}).filter(([, v]) => v !== undefined && v !== null && v !== "" && v !== false);
      return p.length ? "?" + p.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join("&") : "";
    };

    api.health = () => request("GET", "/api/health");
    api.register = (body) => request("POST", "/api/auth/register", body);
    api.login = (body) => request("POST", "/api/auth/login", body);
    api.me = () => request("GET", "/api/auth/me");
    api.logout = async () => { api.token = null; };

    api.listBooks = (q) => request("GET", "/api/books" + qs(q));
    api.categories = () => request("GET", "/api/books/categories");
    api.getBook = (id) => request("GET", `/api/books/${id}`);
    api.createBook = (body) => request("POST", "/api/books", body);
    api.updateBook = (id, body) => request("PUT", `/api/books/${id}`, body);
    api.deleteBook = (id) => request("DELETE", `/api/books/${id}`);

    api.getCart = () => request("GET", "/api/cart");
    api.addToCart = (body) => request("POST", "/api/cart", body);
    api.setCartQty = (bookId, quantity) => request("PUT", `/api/cart/${bookId}`, { quantity });
    api.removeFromCart = (bookId) => request("DELETE", `/api/cart/${bookId}`);
    api.clearCart = () => request("DELETE", "/api/cart");

    api.checkout = (shippingAddress) => request("POST", "/api/orders", { shippingAddress });
    api.myOrders = () => request("GET", "/api/orders");
    api.cancelOrder = (id) => request("PATCH", `/api/orders/${id}/cancel`);

    api.adminStats = () => request("GET", "/api/admin/stats");
    api.adminOrders = (status) => request("GET", "/api/admin/orders" + qs({ status }));
    api.adminSetStatus = (id, status) => request("PATCH", `/api/admin/orders/${id}/status`, { status });
    api.adminUsers = () => request("GET", "/api/admin/users");

    api.demoAccounts = {
      admin: { email: "admin@bookstore.com", password: "Admin@123" },
      customer: { email: "student@example.com", password: "Student@123" },
    };
    return api;
  }

  global.RemoteApi = { create };
})(window);
