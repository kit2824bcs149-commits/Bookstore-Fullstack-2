"use strict";
/*
 * BROWSER BACKEND (no installation needed)
 * ----------------------------------------
 * This file behaves like the Node.js server, but runs inside the browser and keeps its
 * "database" in localStorage. It has the SAME rules as server/src: login with hashed
 * passwords + tokens, admin-only actions, stock checks, all-or-nothing checkout, etc.
 *
 * Every method returns the same JSON shape as the real REST API, so app.js does not
 * care whether it talks to this file or to the Node server (api-remote.js).
 */
(function (global) {
  class ApiError extends Error {
    constructor(status, message, details) {
      super(message);
      this.status = status;
      this.details = details;
    }
  }

  const DB_KEY = "booknest_db_v1";
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const STATUSES = ["placed", "shipped", "delivered", "cancelled"];
  const NEXT = { placed: ["shipped", "cancelled"], shipped: ["delivered"], delivered: [], cancelled: [] };
  const DEMO_ADMIN = { name: "Store Admin", email: "admin@bookstore.com", password: "Admin@123" };
  const DEMO_CUSTOMER = { name: "Demo Student", email: "student@example.com", password: "Student@123" };

  const cmpText = (x, y) => String(x).localeCompare(String(y), undefined, { sensitivity: "base" });
  const SORTS = {
    newest: (a, b) => b.id - a.id,
    "title-asc": (a, b) => cmpText(a.title, b.title),
    "title-desc": (a, b) => cmpText(b.title, a.title),
    "price-asc": (a, b) => a.price - b.price,
    "price-desc": (a, b) => b.price - a.price,
    "rating-desc": (a, b) => (b.rating ?? -1) - (a.rating ?? -1),
    "year-desc": (a, b) => (b.year ?? 0) - (a.year ?? 0),
    "year-asc": (a, b) => (a.year ?? 9999) - (b.year ?? 9999),
  };

  /* ---------- small helpers ---------- */
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const now = () => new Date().toISOString().slice(0, 19).replace("T", " ");
  const badRequest = (msg, details) => new ApiError(400, msg, details);

  function toHex(buf) {
    return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  function randomHex(bytes) {
    const arr = new Uint8Array(bytes);
    (global.crypto || {}).getRandomValues ? global.crypto.getRandomValues(arr) : arr.forEach((_, i) => (arr[i] = Math.floor(Math.random() * 256)));
    return toHex(arr);
  }

  // Password hashing: PBKDF2 (never store plain passwords). Falls back to a simple hash if the
  // browser blocks the crypto API - that fallback is for demo only.
  async function hashPassword(password, saltHex) {
    const subtle = global.crypto && global.crypto.subtle;
    if (subtle) {
      const key = await subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
      const salt = new Uint8Array(saltHex.match(/.{2}/g).map((h) => parseInt(h, 16)));
      const bits = await subtle.deriveBits({ name: "PBKDF2", salt, iterations: 60000, hash: "SHA-256" }, key, 256);
      return "pbkdf2$" + saltHex + "$" + toHex(bits);
    }
    let h = 5381;
    for (const ch of saltHex + password) h = ((h << 5) + h + ch.charCodeAt(0)) >>> 0;
    return "djb2$" + saltHex + "$" + h.toString(16);
  }
  async function verifyPassword(password, stored) {
    const salt = stored.split("$")[1];
    return (await hashPassword(password, salt)) === stored;
  }

  /* ---------- validation (same rules as the server) ---------- */
  function vString(errors, body, field, { min = 1, max = 200, required = true } = {}) {
    const raw = body[field];
    if (raw === undefined || raw === null || raw === "") {
      if (required) errors[field] = `${field} is required`;
      return undefined;
    }
    if (typeof raw !== "string") { errors[field] = `${field} must be text`; return undefined; }
    const v = raw.trim();
    if (v.length < min || v.length > max) { errors[field] = `${field} must be ${min}-${max} characters`; return undefined; }
    return v;
  }
  function vNumber(errors, body, field, { min = -Infinity, max = Infinity, integer = false, required = true } = {}) {
    const raw = body[field];
    if (raw === undefined || raw === null || raw === "") {
      if (required) errors[field] = `${field} is required`;
      return undefined;
    }
    const v = typeof raw === "string" && raw.trim() !== "" ? Number(raw) : raw;
    if (typeof v !== "number" || !Number.isFinite(v)) { errors[field] = `${field} must be a number`; return undefined; }
    if (integer && !Number.isInteger(v)) { errors[field] = `${field} must be a whole number`; return undefined; }
    if (v < min || v > max) { errors[field] = `${field} must be between ${min} and ${max}`; return undefined; }
    return v;
  }
  function throwIfInvalid(errors) {
    if (Object.keys(errors).length) throw badRequest("Validation failed", errors);
  }
  function idParam(value, name = "id") {
    const n = Number(value);
    if (!Number.isInteger(n) || n < 1) throw badRequest(`Invalid ${name}`);
    return n;
  }
  function readBookBody(body, partial) {
    const errors = {};
    const req = !partial;
    const data = {
      title: vString(errors, body, "title", { max: 200, required: req }),
      author: vString(errors, body, "author", { max: 120, required: req }),
      category: vString(errors, body, "category", { max: 60, required: req }),
      year: vNumber(errors, body, "year", { min: 1000, max: new Date().getFullYear() + 1, integer: true, required: false }),
      price: vNumber(errors, body, "price", { min: 1, max: 100000, required: req }),
      stock: vNumber(errors, body, "stock", { min: 0, max: 100000, integer: true, required: false }),
      rating: vNumber(errors, body, "rating", { min: 0, max: 5, required: false }),
      description: vString(errors, body, "description", { max: 2000, required: false }),
    };
    throwIfInvalid(errors);
    return data;
  }

  const qs = (q) => {
    const p = Object.entries(q || {}).filter(([, v]) => v !== undefined && v !== null && v !== "" && v !== false);
    return p.length ? "?" + p.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join("&") : "";
  };

  /* ---------- the API ---------- */
  async function create(onLog) {
    let db = load();
    if (!db) {
      db = await seed();
      save();
    }

    function load() {
      try {
        const parsed = JSON.parse(localStorage.getItem(DB_KEY));
        return parsed && Array.isArray(parsed.books) && Array.isArray(parsed.users) ? parsed : null;
      } catch { return null; }
    }
    function save() {
      try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch { /* storage blocked: keep working in memory */ }
    }
    async function seed() {
      const fresh = { nextIds: { users: 1, books: 1, orders: 1 }, users: [], books: [], carts: {}, orders: [], sessions: {} };
      for (const [u, role] of [[DEMO_ADMIN, "admin"], [DEMO_CUSTOMER, "customer"]]) {
        const salt = randomHex(16);
        fresh.users.push({ id: fresh.nextIds.users++, name: u.name, email: u.email, password_hash: await hashPassword(u.password, salt), role, created_at: now() });
      }
      for (const b of global.SEED_BOOKS || []) {
        fresh.books.push({ id: fresh.nextIds.books++, title: b.title, author: b.author, category: b.category, year: b.year ?? null,
          price: b.price, stock: b.stock ?? 0, rating: b.rating ?? null, description: b.description ?? null, created_at: now() });
      }
      return fresh;
    }

    const api = {
      mode: "local",
      label: "Browser backend",
      token: null,
      demoAccounts: { admin: DEMO_ADMIN, customer: DEMO_CUSTOMER },
    };

    // Runs one "request": waits a moment (like a network), logs it, converts errors.
    async function serve(method, path, okStatus, fn) {
      const t0 = performance.now();
      await sleep(25);
      try {
        const out = await fn();
        onLog && onLog({ method, path, status: okStatus, ms: Math.round(performance.now() - t0) });
        return clone(out);
      } catch (e) {
        if (e instanceof ApiError) {
          onLog && onLog({ method, path, status: e.status, ms: Math.round(performance.now() - t0) });
        }
        throw e;
      }
    }

    function authUser() {
      const s = api.token && db.sessions[api.token];
      if (!api.token) throw new ApiError(401, "Authentication required");
      if (!s || s.exp < Date.now()) throw new ApiError(401, "Invalid or expired token");
      const u = db.users.find((x) => x.id === s.userId);
      if (!u) throw new ApiError(401, "User no longer exists");
      return u;
    }
    function adminUser() {
      const u = authUser();
      if (u.role !== "admin") throw new ApiError(403, "Admin access required");
      return u;
    }
    const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });
    function startSession(u) {
      const token = randomHex(24);
      db.sessions[token] = { userId: u.id, exp: Date.now() + 7 * 24 * 3600 * 1000 };
      save();
      return token;
    }
    const findBook = (id) => db.books.find((b) => b.id === id);

    function readCart(userId) {
      const lines = db.carts[userId] || [];
      const items = lines
        .map((l) => ({ l, b: findBook(l.bookId) }))
        .filter((x) => x.b)
        .map(({ l, b }) => ({ bookId: b.id, title: b.title, author: b.author, price: b.price, stock: b.stock, quantity: l.quantity, lineTotal: b.price * l.quantity }));
      return {
        items,
        itemCount: items.reduce((s, i) => s + i.quantity, 0),
        total: items.reduce((s, i) => s + i.lineTotal, 0),
      };
    }
    function orderOut(o) {
      return { id: o.id, user_id: o.user_id, total: o.total, status: o.status, shipping_address: o.shipping_address, created_at: o.created_at, items: o.items.map((i) => ({ ...i, lineTotal: i.price * i.quantity })) };
    }
    function restock(order) {
      for (const it of order.items) {
        const b = it.bookId != null && findBook(it.bookId);
        if (b) b.stock += it.quantity;
      }
    }

    /* ----- Auth ----- */
    api.register = (body) => serve("POST", "/api/auth/register", 201, async () => {
      const errors = {};
      const name = vString(errors, body, "name", { min: 2, max: 60 });
      const email = (vString(errors, body, "email", { max: 120 }) || "").toLowerCase();
      const password = vString(errors, body, "password", { min: 8, max: 72 });
      if (email && !EMAIL_RE.test(email)) errors.email = "email is not valid";
      throwIfInvalid(errors);
      if (db.users.some((u) => u.email === email)) throw new ApiError(409, "This email is already registered");
      const user = { id: db.nextIds.users++, name, email, password_hash: await hashPassword(password, randomHex(16)), role: "customer", created_at: now() };
      db.users.push(user);
      const token = startSession(user);
      return { user: publicUser(user), token };
    });

    api.login = ({ email, password }) => serve("POST", "/api/auth/login", 200, async () => {
      const mail = typeof email === "string" ? email.trim().toLowerCase() : "";
      if (!mail || typeof password !== "string" || !password) throw badRequest("email and password are required");
      const user = db.users.find((u) => u.email === mail);
      const ok = user ? await verifyPassword(password, user.password_hash) : false;
      if (!user || !ok) throw new ApiError(401, "Invalid email or password");
      return { user: publicUser(user), token: startSession(user) };
    });

    api.me = () => serve("GET", "/api/auth/me", 200, () => ({ user: publicUser(authUser()) }));
    api.logout = async () => {
      if (api.token && db.sessions[api.token]) { delete db.sessions[api.token]; save(); }
      api.token = null;
    };

    /* ----- Books ----- */
    api.listBooks = (q = {}) => serve("GET", "/api/books" + qs(q), 200, () => {
      const page = Math.max(1, parseInt(q.page, 10) || 1);
      const limit = Math.min(50, Math.max(1, parseInt(q.limit, 10) || 12));
      const text = typeof q.search === "string" ? q.search.trim().toLowerCase() : "";
      const cat = typeof q.category === "string" ? q.category.trim().toLowerCase() : "";
      const min = q.minPrice !== undefined && q.minPrice !== "" && Number.isFinite(Number(q.minPrice)) ? Number(q.minPrice) : null;
      const max = q.maxPrice !== undefined && q.maxPrice !== "" && Number.isFinite(Number(q.maxPrice)) ? Number(q.maxPrice) : null;
      const inStock = q.inStock === true || q.inStock === "true";

      let list = db.books.filter((b) => {
        if (text && ![b.title, b.author, b.category].some((f) => f.toLowerCase().includes(text))) return false;
        if (cat && b.category.toLowerCase() !== cat) return false;
        if (min !== null && b.price < min) return false;
        if (max !== null && b.price > max) return false;
        if (inStock && b.stock <= 0) return false;
        return true;
      });
      const cmp = SORTS[q.sort] || SORTS.newest;
      list = list.sort((a, b) => cmp(a, b) || a.id - b.id);
      const total = list.length;
      return {
        data: list.slice((page - 1) * limit, page * limit),
        pagination: { page, limit, total, totalPages: Math.max(1, Math.ceil(total / limit)) },
      };
    });

    api.categories = () => serve("GET", "/api/books/categories", 200, () => {
      const map = new Map();
      for (const b of db.books) map.set(b.category, (map.get(b.category) || 0) + 1);
      return { data: [...map].map(([name, books]) => ({ name, books })).sort((a, b) => cmpText(a.name, b.name)) };
    });

    api.getBook = (id) => serve("GET", `/api/books/${id}`, 200, () => {
      const book = findBook(idParam(id));
      if (!book) throw new ApiError(404, "Book not found");
      return { data: book };
    });

    api.createBook = (body) => serve("POST", "/api/books", 201, () => {
      adminUser();
      const b = readBookBody(body, false);
      const book = { id: db.nextIds.books++, title: b.title, author: b.author, category: b.category, year: b.year ?? null,
        price: b.price, stock: b.stock ?? 0, rating: b.rating ?? null, description: b.description ?? null, created_at: now() };
      db.books.push(book);
      save();
      return { data: book };
    });

    api.updateBook = (id, body) => serve("PUT", `/api/books/${id}`, 200, () => {
      adminUser();
      const book = findBook(idParam(id));
      if (!book) throw new ApiError(404, "Book not found");
      const changes = readBookBody(body, true);
      for (const [k, v] of Object.entries(changes)) if (v !== undefined) book[k] = v;
      save();
      return { data: book };
    });

    api.deleteBook = (id) => serve("DELETE", `/api/books/${id}`, 204, () => {
      adminUser();
      const n = idParam(id);
      const i = db.books.findIndex((b) => b.id === n);
      if (i < 0) throw new ApiError(404, "Book not found");
      db.books.splice(i, 1);
      for (const k of Object.keys(db.carts)) db.carts[k] = db.carts[k].filter((l) => l.bookId !== n);
      for (const o of db.orders) for (const it of o.items) if (it.bookId === n) it.bookId = null;
      save();
      return {};
    });

    /* ----- Cart ----- */
    api.getCart = () => serve("GET", "/api/cart", 200, () => readCart(authUser().id));

    api.addToCart = ({ bookId, quantity }) => serve("POST", "/api/cart", 201, () => {
      const user = authUser();
      const errors = {};
      const id = vNumber(errors, { bookId }, "bookId", { min: 1, integer: true });
      const qty = vNumber(errors, { quantity }, "quantity", { min: 1, max: 20, integer: true, required: false }) ?? 1;
      throwIfInvalid(errors);
      const book = findBook(id);
      if (!book) throw new ApiError(404, "Book not found");
      const lines = (db.carts[user.id] = db.carts[user.id] || []);
      const line = lines.find((l) => l.bookId === id);
      const newQty = (line ? line.quantity : 0) + qty;
      if (newQty > book.stock) throw badRequest(`Only ${book.stock} copies of "${book.title}" are in stock`);
      if (line) line.quantity = newQty; else lines.push({ bookId: id, quantity: qty });
      save();
      return readCart(user.id);
    });

    api.setCartQty = (bookId, quantity) => serve("PUT", `/api/cart/${bookId}`, 200, () => {
      const user = authUser();
      const id = idParam(bookId, "bookId");
      const errors = {};
      const qty = vNumber(errors, { quantity }, "quantity", { min: 1, max: 20, integer: true });
      throwIfInvalid(errors);
      const line = (db.carts[user.id] || []).find((l) => l.bookId === id);
      if (!line) throw new ApiError(404, "This book is not in your cart");
      const book = findBook(id);
      if (qty > book.stock) throw badRequest(`Only ${book.stock} copies of "${book.title}" are in stock`);
      line.quantity = qty;
      save();
      return readCart(user.id);
    });

    api.removeFromCart = (bookId) => serve("DELETE", `/api/cart/${bookId}`, 200, () => {
      const user = authUser();
      const id = idParam(bookId, "bookId");
      const lines = db.carts[user.id] || [];
      if (!lines.some((l) => l.bookId === id)) throw new ApiError(404, "This book is not in your cart");
      db.carts[user.id] = lines.filter((l) => l.bookId !== id);
      save();
      return readCart(user.id);
    });

    api.clearCart = () => serve("DELETE", "/api/cart", 200, () => {
      const user = authUser();
      db.carts[user.id] = [];
      save();
      return readCart(user.id);
    });

    /* ----- Orders ----- */
    api.checkout = (shippingAddress) => serve("POST", "/api/orders", 201, () => {
      const user = authUser();
      const errors = {};
      const address = vString(errors, { shippingAddress }, "shippingAddress", { min: 10, max: 300 });
      throwIfInvalid(errors);

      const lines = (db.carts[user.id] || []).filter((l) => findBook(l.bookId));
      if (lines.length === 0) throw badRequest("Your cart is empty");

      // 1) check everything first ...
      for (const l of lines) {
        const b = findBook(l.bookId);
        if (b.stock < l.quantity) throw badRequest(`Not enough stock for "${b.title}" (available: ${b.stock})`);
      }
      // 2) ... only then change anything (all-or-nothing)
      const items = lines.map((l) => {
        const b = findBook(l.bookId);
        b.stock -= l.quantity;
        return { bookId: b.id, title: b.title, price: b.price, quantity: l.quantity };
      });
      const order = {
        id: db.nextIds.orders++, user_id: user.id, status: "placed", shipping_address: address, created_at: now(), items,
        total: items.reduce((s, i) => s + i.price * i.quantity, 0),
      };
      db.orders.push(order);
      db.carts[user.id] = [];
      save();
      return { data: orderOut(order) };
    });

    api.myOrders = () => serve("GET", "/api/orders", 200, () => {
      const user = authUser();
      return { data: db.orders.filter((o) => o.user_id === user.id).sort((a, b) => b.id - a.id).map(orderOut) };
    });

    api.cancelOrder = (id) => serve("PATCH", `/api/orders/${id}/cancel`, 200, () => {
      const user = authUser();
      const order = db.orders.find((o) => o.id === idParam(id));
      if (!order) throw new ApiError(404, "Order not found");
      if (order.user_id !== user.id) throw new ApiError(403, "You do not have permission to do this");
      if (order.status !== "placed") throw badRequest(`A ${order.status} order cannot be cancelled`);
      restock(order);
      order.status = "cancelled";
      save();
      return { data: orderOut(order) };
    });

    /* ----- Admin ----- */
    api.adminStats = () => serve("GET", "/api/admin/stats", 200, () => {
      adminUser();
      const live = db.orders.filter((o) => o.status !== "cancelled");
      const byStatus = {};
      for (const o of db.orders) byStatus[o.status] = (byStatus[o.status] || 0) + 1;
      const sold = new Map();
      for (const o of live) for (const it of o.items) sold.set(it.title, (sold.get(it.title) || 0) + it.quantity);
      return {
        users: db.users.filter((u) => u.role === "customer").length,
        books: db.books.length,
        outOfStock: db.books.filter((b) => b.stock === 0).length,
        orders: db.orders.length,
        revenue: live.reduce((s, o) => s + o.total, 0),
        ordersByStatus: Object.entries(byStatus).map(([status, count]) => ({ status, count })),
        topBooks: [...sold].map(([title, soldQty]) => ({ title, sold: soldQty })).sort((a, b) => b.sold - a.sold).slice(0, 5),
      };
    });

    api.adminOrders = (status) => serve("GET", "/api/admin/orders" + qs({ status }), 200, () => {
      adminUser();
      if (status && !STATUSES.includes(status)) throw badRequest(`status must be one of: ${STATUSES.join(", ")}`);
      const data = db.orders
        .filter((o) => !status || o.status === status)
        .sort((a, b) => b.id - a.id)
        .map((o) => {
          const u = db.users.find((x) => x.id === o.user_id);
          return { id: o.id, user_id: o.user_id, total: o.total, status: o.status, shipping_address: o.shipping_address, created_at: o.created_at,
            customerName: u ? u.name : "(deleted)", customerEmail: u ? u.email : "" };
        });
      return { data };
    });

    api.adminSetStatus = (id, status) => serve("PATCH", `/api/admin/orders/${id}/status`, 200, () => {
      adminUser();
      const n = idParam(id);
      if (!STATUSES.includes(status)) throw badRequest(`status must be one of: ${STATUSES.join(", ")}`);
      const order = db.orders.find((o) => o.id === n);
      if (!order) throw new ApiError(404, "Order not found");
      if (!NEXT[order.status].includes(status)) throw badRequest(`Cannot change an order from "${order.status}" to "${status}"`);
      if (status === "cancelled") restock(order);
      order.status = status;
      save();
      return { data: { id: order.id, user_id: order.user_id, total: order.total, status: order.status, shipping_address: order.shipping_address, created_at: order.created_at } };
    });

    api.adminUsers = () => serve("GET", "/api/admin/users", 200, () => {
      adminUser();
      return {
        data: db.users.map((u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, createdAt: u.created_at, orders: db.orders.filter((o) => o.user_id === u.id).length })),
      };
    });

    api.resetData = async () => {
      try { localStorage.removeItem(DB_KEY); } catch { /* ignore */ }
      db = await seed();
      save();
      api.token = null;
    };

    return api;
  }

  global.ApiError = global.ApiError || ApiError;
  global.LocalApi = { create, ApiError };
})(window);
