// Sample books (same data the Node server uses)
window.SEED_BOOKS = [
  {
    "title": "Wings of Fire",
    "author": "A. P. J. Abdul Kalam",
    "category": "Biography",
    "year": 1999,
    "price": 299,
    "rating": 4.7,
    "description": "The autobiography of Dr. A. P. J. Abdul Kalam, tracing his journey from Rameswaram to leading India's missile and space programmes.",
    "stock": 15
  },
  {
    "title": "The Alchemist",
    "author": "Paulo Coelho",
    "category": "Fiction",
    "year": 1988,
    "price": 350,
    "rating": 4.4,
    "description": "A shepherd boy named Santiago travels in search of treasure and learns to listen to his heart along the way.",
    "stock": 22
  },
  {
    "title": "Atomic Habits",
    "author": "James Clear",
    "category": "Self-Help",
    "year": 2018,
    "price": 499,
    "rating": 4.8,
    "description": "A practical guide to building good habits and breaking bad ones through small, consistent changes.",
    "stock": 29
  },
  {
    "title": "Clean Code",
    "author": "Robert C. Martin",
    "category": "Technology",
    "year": 2008,
    "price": 899,
    "rating": 4.6,
    "description": "A handbook of agile software craftsmanship that teaches how to write readable, maintainable code.",
    "stock": 13
  },
  {
    "title": "The Pragmatic Programmer",
    "author": "Andrew Hunt & David Thomas",
    "category": "Technology",
    "year": 1999,
    "price": 950,
    "rating": 4.7,
    "description": "Timeless advice on the habits, tools and mindset of effective software developers.",
    "stock": 20
  },
  {
    "title": "Sapiens",
    "author": "Yuval Noah Harari",
    "category": "History",
    "year": 2011,
    "price": 520,
    "rating": 4.5,
    "description": "A brief history of humankind, from the Stone Age to the modern age of technology.",
    "stock": 27
  },
  {
    "title": "Harry Potter and the Philosopher's Stone",
    "author": "J. K. Rowling",
    "category": "Fantasy",
    "year": 1997,
    "price": 399,
    "rating": 4.9,
    "description": "A boy discovers on his eleventh birthday that he is a wizard and begins his first year at Hogwarts.",
    "stock": 11
  },
  {
    "title": "The Hobbit",
    "author": "J. R. R. Tolkien",
    "category": "Fantasy",
    "year": 1937,
    "price": 450,
    "rating": 4.7,
    "description": "Bilbo Baggins is swept into a quest to reclaim a dwarf kingdom from the dragon Smaug.",
    "stock": 18
  },
  {
    "title": "1984",
    "author": "George Orwell",
    "category": "Fiction",
    "year": 1949,
    "price": 280,
    "rating": 4.6,
    "description": "A dystopian novel about surveillance, propaganda and the loss of individual freedom.",
    "stock": 25
  },
  {
    "title": "Pride and Prejudice",
    "author": "Jane Austen",
    "category": "Classic",
    "year": 1813,
    "price": 199,
    "rating": 4.6,
    "description": "Elizabeth Bennet and Mr. Darcy navigate class, manners and misjudgement in Regency England.",
    "stock": 9
  },
  {
    "title": "To Kill a Mockingbird",
    "author": "Harper Lee",
    "category": "Classic",
    "year": 1960,
    "price": 320,
    "rating": 4.8,
    "description": "Seen through a young girl's eyes, a lawyer defends an innocent man in a prejudiced Southern town.",
    "stock": 16
  },
  {
    "title": "The Great Gatsby",
    "author": "F. Scott Fitzgerald",
    "category": "Classic",
    "year": 1925,
    "price": 220,
    "rating": 4.3,
    "description": "A portrait of wealth, love and illusion in the Jazz Age, told through the mysterious Jay Gatsby.",
    "stock": 23
  },
  {
    "title": "Ponniyin Selvan",
    "author": "Kalki Krishnamurthy",
    "category": "Historical",
    "year": 1954,
    "price": 750,
    "rating": 4.9,
    "description": "An epic Tamil historical novel of palace intrigue, adventure and the rise of the Chola prince Arulmozhi Varman.",
    "stock": 30
  },
  {
    "title": "Introduction to Algorithms",
    "author": "Cormen, Leiserson, Rivest & Stein",
    "category": "Technology",
    "year": 1990,
    "price": 1450,
    "rating": 4.6,
    "description": "The standard university textbook covering a wide range of algorithms in depth.",
    "stock": 14
  },
  {
    "title": "Rich Dad Poor Dad",
    "author": "Robert T. Kiyosaki",
    "category": "Finance",
    "year": 1997,
    "price": 360,
    "rating": 4.2,
    "description": "Contrasting the money lessons of two father figures to explain financial independence.",
    "stock": 21
  },
  {
    "title": "The Psychology of Money",
    "author": "Morgan Housel",
    "category": "Finance",
    "year": 2020,
    "price": 399,
    "rating": 4.7,
    "description": "Short stories about how people think about money and why behaviour matters more than knowledge.",
    "stock": 28
  },
  {
    "title": "Deep Work",
    "author": "Cal Newport",
    "category": "Self-Help",
    "year": 2016,
    "price": 450,
    "rating": 4.5,
    "description": "Rules for focused success in a distracted world and how to build the habit of deep concentration.",
    "stock": 12
  },
  {
    "title": "A Brief History of Time",
    "author": "Stephen Hawking",
    "category": "Science",
    "year": 1988,
    "price": 380,
    "rating": 4.5,
    "description": "An accessible introduction to cosmology: the Big Bang, black holes and the nature of time.",
    "stock": 19
  },
  {
    "title": "Cosmos",
    "author": "Carl Sagan",
    "category": "Science",
    "year": 1980,
    "price": 499,
    "rating": 4.7,
    "description": "A sweeping journey through the universe and humanity's place within it.",
    "stock": 26
  },
  {
    "title": "The Diary of a Young Girl",
    "author": "Anne Frank",
    "category": "Biography",
    "year": 1947,
    "price": 250,
    "rating": 4.7,
    "description": "The wartime diary of a teenage girl hiding with her family in occupied Amsterdam.",
    "stock": 10
  },
  {
    "title": "Gitanjali",
    "author": "Rabindranath Tagore",
    "category": "Poetry",
    "year": 1910,
    "price": 150,
    "rating": 4.6,
    "description": "A collection of devotional poems that helped Tagore win the Nobel Prize in Literature in 1913.",
    "stock": 17
  },
  {
    "title": "The God of Small Things",
    "author": "Arundhati Roy",
    "category": "Fiction",
    "year": 1997,
    "price": 399,
    "rating": 4.3,
    "description": "A story of twins, family secrets and forbidden love in Kerala, winner of the 1997 Booker Prize.",
    "stock": 24
  },
  {
    "title": "Python Crash Course",
    "author": "Eric Matthes",
    "category": "Technology",
    "year": 2015,
    "price": 799,
    "rating": 4.6,
    "description": "A hands-on, project-based introduction to programming with Python.",
    "stock": 8
  },
  {
    "title": "You Don't Know JS Yet",
    "author": "Kyle Simpson",
    "category": "Technology",
    "year": 2020,
    "price": 650,
    "rating": 4.5,
    "description": "A deep dive into the core mechanisms of the JavaScript language.",
    "stock": 15
  },
  {
    "title": "Thinking, Fast and Slow",
    "author": "Daniel Kahneman",
    "category": "Science",
    "year": 2011,
    "price": 550,
    "rating": 4.5,
    "description": "How two systems of thought shape our judgements, and the biases that follow.",
    "stock": 22
  },
  {
    "title": "The Selfish Gene",
    "author": "Richard Dawkins",
    "category": "Science",
    "year": 1976,
    "price": 420,
    "rating": 4.4,
    "description": "A gene-centred view of evolution that popularised ideas such as the meme.",
    "stock": 29
  }
];
