"use strict";
/*
 * BookNest – screens and user interaction.
 * All data comes from `state.api`, which is EITHER the in-browser backend (api-local.js)
 * OR the real Node server (api-remote.js). Both have the same methods.
 */
(function () {
  const DEFAULT_URL = "http://localhost:3000";
  const PREF_KEY = "booknest_pref_v1";
  const ADDR_KEY = "booknest_address";
  const PAGE_SIZE = 8;
  const ApiError = window.ApiError;

  const state = {
    api: null,
    mode: "local",
    serverUrl: DEFAULT_URL,
    user: null,
    cart: { items: [], itemCount: 0, total: 0 },
    shop: { search: "", category: "", sort: "newest", maxPrice: "", inStock: false, page: 1 },
    adminTab: "dashboard",
    adminBooks: { search: "", page: 1 },
    adminOrderFilter: "",
    afterLogin: null,
    logs: [],
  };

  /* ===================== helpers ===================== */
  const $ = (sel, root = document) => root.querySelector(sel);
  const view = $("#view");

  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (n) => "₹" + Number(n).toLocaleString("en-IN");
  const emptyCart = () => ({ items: [], itemCount: 0, total: 0 });
  const fmtDate = (s) => {
    const d = new Date(String(s).replace(" ", "T") + "Z");
    return isNaN(d) ? s : d.toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };

  function coverBg(title) {
    let h = 0;
    for (const ch of title) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    const h1 = h % 360, h2 = (h1 + 40 + ((h >> 8) % 60)) % 360;
    return `linear-gradient(155deg, hsl(${h1} 55% 32%), hsl(${h2} 60% 22%))`;
  }

  function loadPref() {
    try { return JSON.parse(localStorage.getItem(PREF_KEY)) || {}; } catch { return {}; }
  }
  function savePref() {
    try {
      localStorage.setItem(PREF_KEY, JSON.stringify({ mode: state.mode, url: state.serverUrl, token: state.api && state.api.token }));
    } catch { /* storage blocked */ }
  }

  let toastTimer;
  function toast(msg, type = "ok") {
    const el = $("#toast");
    el.textContent = msg;
    el.className = "toast show " + type;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.className = "toast"), 3200);
  }

  function handleError(e) {
    if (e instanceof ApiError) {
      if (e.status === 401 && state.user) {
        state.user = null; state.cart = emptyCart();
        if (state.api) state.api.token = null;
        savePref(); renderHeader();
        toast("Your session expired. Please log in again.", "error");
        navigate("#/login");
        return;
      }
      let msg = e.message;
      if (e.details) msg += ": " + Object.values(e.details)[0];
      toast(msg, "error");
    } else {
      console.error(e);
      toast("Something went wrong. See the browser console.", "error");
    }
  }
  const guard = (fn) => async (...args) => { try { return await fn(...args); } catch (e) { handleError(e); } };

  function navigate(hash) {
    if (location.hash === hash) route(); else location.hash = hash;
  }

  /* ===================== API log ===================== */
  function onLog(entry) {
    state.logs.unshift({ ...entry, time: new Date().toLocaleTimeString("en-IN", { hour12: false }) });
    state.logs.length = Math.min(state.logs.length, 40);
    $("#log-count").textContent = state.logs.length;
    if (!$("#log-panel").classList.contains("hidden")) renderLog();
  }
  function renderLog() {
    const note = state.mode === "local"
      ? "Requests are handled by the backend code running inside this browser."
      : `Real HTTP requests to ${esc(state.serverUrl)}`;
    const rows = state.logs.map((l) => {
      const cls = l.status === 0 ? "s0" : l.status < 300 ? "s2" : l.status < 500 ? "s4" : "s5";
      return `<li><span class="lg-time">${l.time}</span><b class="lg-m lg-${l.method}">${l.method}</b><code>${esc(l.path)}</code><span class="lg-status ${cls}">${l.status || "ERR"}</span><span class="lg-ms">${l.ms} ms</span></li>`;
    }).join("");
    $("#log-panel").innerHTML = `
      <div class="log-head"><strong>API requests</strong><span>${note}</span>
        <button class="link-btn" type="button" data-action="log-clear">Clear</button></div>
      <ul class="log-list">${rows || '<li class="muted">No requests yet.</li>'}</ul>`;
  }

  /* ===================== connect / header ===================== */
  async function connect(token) {
    state.user = null;
    state.cart = emptyCart();
    try {
      if (state.mode === "remote") {
        state.api = window.RemoteApi.create(state.serverUrl, onLog);
        await state.api.health();
      } else {
        state.api = await window.LocalApi.create(onLog);
      }
    } catch (e) {
      if (state.mode !== "remote") throw e;
      toast(e.message + " Using the browser backend instead.", "error");
      state.mode = "local";
      state.api = await window.LocalApi.create(onLog);
      token = null;
    }
    if (token) {
      state.api.token = token;
      try {
        state.user = (await state.api.me()).user;
        state.cart = await state.api.getCart();
      } catch {
        state.api.token = null;
        state.user = null;
      }
    }
    savePref();
    renderHeader();
  }

  function renderHeader() {
    const path = currentPath();
    const link = (href, label, match) => `<a href="${href}" class="${match ? "active" : ""}">${label}</a>`;
    const badge = state.mode === "local"
      ? '<span aria-hidden="true">🧪</span><span class="bt-text"> Browser backend</span>'
      : '<span aria-hidden="true">🖥️</span><span class="bt-text"> Node server</span>';
    $("#header").innerHTML = `
      <a class="brand" href="#/">📚 BookNest</a>
      <nav class="main-nav" aria-label="Main">
        ${link("#/", "Shop", path === "/")}
        ${state.user ? link("#/orders", "My orders", path === "/orders") : ""}
        ${state.user && state.user.role === "admin" ? link("#/admin", "Admin", path === "/admin") : ""}
      </nav>
      <div class="header-right">
        <button class="backend-badge ${state.mode}" type="button" data-action="settings" title="Change backend" aria-label="Backend: ${state.mode === "local" ? "browser" : "Node server"}. Click to change">${badge}</button>
        <a class="cart-link ${path === "/cart" ? "active" : ""}" href="#/cart" aria-label="Cart, ${state.cart.itemCount} items">🛒<span class="badge">${state.cart.itemCount}</span></a>
        ${state.user
          ? `<span class="who">Hi, ${esc(state.user.name.split(" ")[0])}${state.user.role === "admin" ? ' <em class="role">admin</em>' : ""}</span>
             <button class="btn small outline" type="button" data-action="logout">Log out</button>`
          : `<a class="btn small outline" href="#/login">Log in</a><a class="btn small" href="#/register">Sign up</a>`}
      </div>`;
  }

  /* ===================== routing ===================== */
  const currentPath = () => (location.hash.replace(/^#/, "") || "/").split("?")[0];

  async function route() {
    closeModal();
    const path = currentPath();
    renderHeader();
    try {
      if (["/cart", "/orders", "/admin"].includes(path) && !state.user) {
        state.afterLogin = "#" + path;
        toast("Please log in first.", "error");
        return navigate("#/login");
      }
      if (path === "/admin" && state.user.role !== "admin") {
        toast("Admin access required.", "error");
        return navigate("#/");
      }
      if (path !== "/") window.scrollTo(0, 0);
      switch (path) {
        case "/": return await viewShop();
        case "/cart": return await viewCart();
        case "/orders": return await viewOrders();
        case "/login": return viewLogin();
        case "/register": return viewRegister();
        case "/admin": return await viewAdmin();
        default: view.innerHTML = `<div class="empty"><p>Page not found.</p><a class="btn" href="#/">Back to shop</a></div>`;
      }
    } catch (e) {
      handleError(e);
      if (e instanceof ApiError && e.status === 0) view.innerHTML = `<div class="empty"><p>${esc(e.message)}</p><button class="btn" data-action="settings">Change backend</button></div>`;
    }
  }

  /* ===================== modal ===================== */
  function openModal(title, html) {
    $("#modal-title").textContent = title;
    $("#modal-body").innerHTML = html;
    $("#modal").classList.remove("hidden");
    document.body.style.overflow = "hidden";
    const first = $("#modal-body input, #modal-body textarea, #modal-body button");
    if (first) first.focus();
  }
  function closeModal() {
    $("#modal").classList.add("hidden");
    document.body.style.overflow = "";
  }

  /* ===================== shop ===================== */
  function stockBadge(b) {
    if (b.stock === 0) return '<span class="stock out">Out of stock</span>';
    if (b.stock <= 5) return `<span class="stock low">Only ${b.stock} left</span>`;
    return '<span class="stock ok">In stock</span>';
  }

  function pagerHtml(p, action) {
    if (p.totalPages <= 1) return "";
    let h = `<button class="page-btn" type="button" data-action="${action}" data-page="${p.page - 1}" ${p.page <= 1 ? "disabled" : ""}>← Prev</button>`;
    for (let i = 1; i <= p.totalPages; i++) {
      h += `<button class="page-btn" type="button" data-action="${action}" data-page="${i}" ${i === p.page ? 'aria-current="page"' : ""}>${i}</button>`;
    }
    h += `<button class="page-btn" type="button" data-action="${action}" data-page="${p.page + 1}" ${p.page >= p.totalPages ? "disabled" : ""}>Next →</button>`;
    return h;
  }

  async function viewShop() {
    if (!$("#shop-results")) {
      const cats = (await state.api.categories()).data;
      const s = state.shop;
      view.innerHTML = `
        <section class="hero">
          <h1>Find your next favourite book</h1>
          <p>Search, cart, checkout and the admin tools all go through a backend API. Open the API log at the bottom to watch the requests.</p>
        </section>
        <div class="toolbar card">
          <label class="field grow"><span>Search</span>
            <input data-shop="search" type="search" placeholder="Title, author or category…" value="${esc(s.search)}" /></label>
          <label class="field"><span>Category</span>
            <select data-shop="category"><option value="">All categories</option>
              ${cats.map((c) => `<option value="${esc(c.name)}" ${c.name === s.category ? "selected" : ""}>${esc(c.name)} (${c.books})</option>`).join("")}
            </select></label>
          <label class="field"><span>Sort by</span>
            <select data-shop="sort">
              ${[["newest", "Newest added"], ["title-asc", "Title A–Z"], ["title-desc", "Title Z–A"], ["price-asc", "Price: low to high"], ["price-desc", "Price: high to low"], ["rating-desc", "Top rated"], ["year-desc", "Newest published"]]
                .map(([v, l]) => `<option value="${v}" ${v === s.sort ? "selected" : ""}>${l}</option>`).join("")}
            </select></label>
          <label class="field"><span>Max price</span>
            <select data-shop="maxPrice">
              ${[["", "Any price"], ["300", "Up to ₹300"], ["500", "Up to ₹500"], ["1000", "Up to ₹1,000"]]
                .map(([v, l]) => `<option value="${v}" ${v === s.maxPrice ? "selected" : ""}>${l}</option>`).join("")}
            </select></label>
          <label class="check"><input type="checkbox" data-shop="inStock" ${s.inStock ? "checked" : ""} /> In stock only</label>
        </div>
        <p id="shop-info" class="muted info" role="status" aria-live="polite"></p>
        <div id="shop-results" class="book-grid"></div>
        <nav id="shop-pager" class="pager" aria-label="Pagination"></nav>`;
    }
    await loadShop();
  }

  async function loadShop() {
    const s = state.shop;
    const res = await state.api.listBooks({ search: s.search, category: s.category, sort: s.sort, maxPrice: s.maxPrice, inStock: s.inStock, page: s.page, limit: PAGE_SIZE });
    const box = $("#shop-results");
    if (!box) return;
    box.innerHTML = res.data.map((b) => `
      <article class="card book">
        <button class="cover" type="button" data-action="details" data-id="${b.id}" style="--cover-bg:${coverBg(b.title)}" aria-label="View details of ${esc(b.title)}">
          <span class="cover-cat">${esc(b.category)}</span>
          <span class="cover-title">${esc(b.title)}</span>
          <span class="cover-author">${esc(b.author)}</span>
        </button>
        <div class="card-body">
          <h3 class="book-title">${esc(b.title)}</h3>
          <p class="muted">${esc(b.author)}</p>
          <div class="row between"><span class="price">${money(b.price)}</span>${stockBadge(b)}</div>
          <button class="btn full" type="button" data-action="add" data-id="${b.id}" ${b.stock === 0 ? "disabled" : ""}>${b.stock === 0 ? "Unavailable" : "Add to cart"}</button>
        </div>
      </article>`).join("") || `<div class="empty wide"><p>📭 No books match your filters.</p></div>`;
    const p = res.pagination;
    const from = p.total ? (p.page - 1) * p.limit + 1 : 0;
    $("#shop-info").textContent = p.total ? `Showing ${from}–${from + res.data.length - 1} of ${p.total} books` : "";
    $("#shop-pager").innerHTML = pagerHtml(p, "shop-page");
  }

  let searchTimer;
  function onShopControl(el) {
    const key = el.dataset.shop;
    state.shop[key] = el.type === "checkbox" ? el.checked : el.value;
    state.shop.page = 1;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(guard(loadShop), key === "search" ? 250 : 0);
  }

  async function requireLogin() {
    state.afterLogin = location.hash || "#/";
    toast("Please log in to add books to your cart.", "error");
    navigate("#/login");
  }

  /* ===================== cart ===================== */
  async function viewCart() {
    state.cart = await state.api.getCart();
    renderHeader();
    const c = state.cart;
    let saved = "";
    try { saved = localStorage.getItem(ADDR_KEY) || ""; } catch { /* ignore */ }
    if (!c.items.length) {
      view.innerHTML = `<h1 class="page-title">Your cart</h1><div class="empty"><p>🛒 Your cart is empty.</p><a class="btn" href="#/">Browse books</a></div>`;
      return;
    }
    view.innerHTML = `
      <h1 class="page-title">Your cart <span class="muted">(${c.itemCount} item${c.itemCount === 1 ? "" : "s"})</span></h1>
      <div class="cart-layout">
        <div class="card table-card">
          <table class="table">
            <thead><tr><th>Book</th><th>Price</th><th>Quantity</th><th>Total</th><th></th></tr></thead>
            <tbody>
              ${c.items.map((i) => `
                <tr>
                  <td data-label="Book"><strong>${esc(i.title)}</strong><br><span class="muted">${esc(i.author)}</span></td>
                  <td data-label="Price">${money(i.price)}</td>
                  <td data-label="Quantity">
                    <div class="stepper">
                      <button type="button" data-action="qty" data-id="${i.bookId}" data-qty="${i.quantity - 1}" aria-label="Decrease quantity" ${i.quantity <= 1 ? "disabled" : ""}>−</button>
                      <span>${i.quantity}</span>
                      <button type="button" data-action="qty" data-id="${i.bookId}" data-qty="${i.quantity + 1}" aria-label="Increase quantity" ${i.quantity >= Math.min(20, i.stock) ? "disabled" : ""}>+</button>
                    </div>
                  </td>
                  <td data-label="Total"><strong>${money(i.lineTotal)}</strong></td>
                  <td><button class="link-btn danger" type="button" data-action="remove" data-id="${i.bookId}">Remove</button></td>
                </tr>`).join("")}
            </tbody>
          </table>
        </div>
        <aside class="card summary">
          <h2>Order summary</h2>
          <div class="row between"><span>Items</span><span>${c.itemCount}</span></div>
          <div class="row between total"><span>Total</span><strong>${money(c.total)}</strong></div>
          <form id="checkout-form" novalidate>
            <label class="field"><span>Shipping address</span>
              <textarea id="ship-address" rows="3" placeholder="House no, street, city, PIN code">${esc(saved)}</textarea></label>
            <p class="form-error" id="checkout-error" role="alert"></p>
            <button class="btn full" type="submit">Place order</button>
          </form>
          <button class="link-btn" type="button" data-action="clear-cart">Empty cart</button>
        </aside>
      </div>`;
  }

  /* ===================== orders ===================== */
  const statusBadge = (s) => `<span class="status ${s}">${s}</span>`;

  async function viewOrders() {
    const orders = (await state.api.myOrders()).data;
    view.innerHTML = `<h1 class="page-title">My orders</h1>` + (orders.length ? orders.map((o) => `
      <article class="card order">
        <div class="row between wrap">
          <div><strong>Order #${o.id}</strong> <span class="muted">· ${fmtDate(o.created_at)}</span></div>
          ${statusBadge(o.status)}
        </div>
        <ul class="order-items">
          ${o.items.map((i) => `<li><span>${esc(i.title)} <span class="muted">× ${i.quantity}</span></span><span>${money(i.lineTotal)}</span></li>`).join("")}
        </ul>
        <div class="row between wrap">
          <span class="muted">Ship to: ${esc(o.shipping_address)}</span>
          <strong>Total ${money(o.total)}</strong>
        </div>
        ${o.status === "placed" ? `<button class="btn small outline danger" type="button" data-action="cancel-order" data-id="${o.id}">Cancel order</button>` : ""}
      </article>`).join("") : `<div class="empty"><p>📦 You have not placed any orders yet.</p><a class="btn" href="#/">Start shopping</a></div>`);
  }

  /* ===================== login / register ===================== */
  function viewLogin() {
    const d = state.api.demoAccounts;
    view.innerHTML = `
      <div class="auth card">
        <h1>Log in</h1>
        <form id="login-form" novalidate>
          <label class="field"><span>Email</span><input id="login-email" type="email" autocomplete="username" required /></label>
          <label class="field"><span>Password</span><input id="login-password" type="password" autocomplete="current-password" required /></label>
          <p class="form-error" id="form-error" role="alert"></p>
          <button class="btn full" type="submit">Log in</button>
        </form>
        <div class="demo-box">
          <p class="muted">Demo accounts:</p>
          <button class="btn small outline" type="button" data-action="demo-fill" data-email="${esc(d.customer.email)}" data-pass="${esc(d.customer.password)}">Customer</button>
          <button class="btn small outline" type="button" data-action="demo-fill" data-email="${esc(d.admin.email)}" data-pass="${esc(d.admin.password)}">Admin</button>
        </div>
        <p class="muted center">New here? <a href="#/register">Create an account</a></p>
      </div>`;
  }

  function viewRegister() {
    view.innerHTML = `
      <div class="auth card">
        <h1>Create account</h1>
        <form id="register-form" novalidate>
          <label class="field"><span>Full name</span><input id="reg-name" type="text" autocomplete="name" /><small class="err" data-err="name"></small></label>
          <label class="field"><span>Email</span><input id="reg-email" type="email" autocomplete="email" /><small class="err" data-err="email"></small></label>
          <label class="field"><span>Password (min 8 characters)</span><input id="reg-password" type="password" autocomplete="new-password" /><small class="err" data-err="password"></small></label>
          <p class="form-error" id="form-error" role="alert"></p>
          <button class="btn full" type="submit">Sign up</button>
        </form>
        <p class="muted center">Already registered? <a href="#/login">Log in</a></p>
      </div>`;
  }

  async function finishLogin(res) {
    state.api.token = res.token;
    state.user = res.user;
    state.cart = await state.api.getCart();
    savePref();
    renderHeader();
    toast(`Welcome, ${res.user.name.split(" ")[0]}!`);
    const next = state.afterLogin || (res.user.role === "admin" ? "#/admin" : "#/");
    state.afterLogin = null;
    navigate(next);
  }

  /* ===================== admin ===================== */
  async function viewAdmin() {
    const tabs = [["dashboard", "Dashboard"], ["books", "Books"], ["orders", "Orders"], ["users", "Users"]];
    view.innerHTML = `
      <h1 class="page-title">Admin panel</h1>
      <div class="tabs" role="tablist">
        ${tabs.map(([k, l]) => `<button class="tab ${state.adminTab === k ? "active" : ""}" type="button" role="tab" aria-selected="${state.adminTab === k}" data-action="admin-tab" data-tab="${k}">${l}</button>`).join("")}
      </div>
      <div id="admin-content"><p class="loading">Loading…</p></div>`;
    await loadAdminTab();
  }

  async function loadAdminTab() {
    const box = $("#admin-content");
    if (!box) return;
    if (state.adminTab === "dashboard") {
      const s = await state.api.adminStats();
      const maxStatus = Math.max(1, ...s.ordersByStatus.map((x) => x.count));
      const maxSold = Math.max(1, ...s.topBooks.map((x) => x.sold));
      box.innerHTML = `
        <div class="stats">
          ${[["Customers", s.users], ["Books", s.books], ["Out of stock", s.outOfStock], ["Orders", s.orders], ["Revenue", money(s.revenue)]]
            .map(([l, v]) => `<div class="stat"><span>${l}</span><strong>${v}</strong></div>`).join("")}
        </div>
        <div class="two-col">
          <section class="card"><h2>Orders by status</h2>
            ${s.ordersByStatus.length ? s.ordersByStatus.map((x) => `
              <div class="bar-row"><span class="bar-label">${statusBadge(x.status)}</span>
                <div class="bar"><i class="${x.status}" style="width:${(x.count / maxStatus) * 100}%"></i></div><b>${x.count}</b></div>`).join("") : '<p class="muted">No orders yet.</p>'}
          </section>
          <section class="card"><h2>Top-selling books</h2>
            ${s.topBooks.length ? s.topBooks.map((x) => `
              <div class="bar-row"><span class="bar-label wide">${esc(x.title)}</span>
                <div class="bar"><i class="sold" style="width:${(x.sold / maxSold) * 100}%"></i></div><b>${x.sold}</b></div>`).join("") : '<p class="muted">No sales yet. Place an order as a customer.</p>'}
          </section>
        </div>`;
    } else if (state.adminTab === "books") {
      const res = await state.api.listBooks({ search: state.adminBooks.search, page: state.adminBooks.page, limit: 10, sort: "title-asc" });
      box.innerHTML = `
        <div class="row between wrap toolbar-lite">
          <input id="admin-book-search" type="search" placeholder="Search books…" value="${esc(state.adminBooks.search)}" />
          <button class="btn" type="button" data-action="book-new">＋ Add book</button>
        </div>
        <div class="card table-card"><table class="table">
          <thead><tr><th>Title</th><th>Category</th><th>Price</th><th>Stock</th><th></th></tr></thead>
          <tbody>${res.data.map((b) => `
            <tr>
              <td data-label="Title"><strong>${esc(b.title)}</strong><br><span class="muted">${esc(b.author)}</span></td>
              <td data-label="Category">${esc(b.category)}</td>
              <td data-label="Price">${money(b.price)}</td>
              <td data-label="Stock"><span class="${b.stock === 0 ? "text-danger" : ""}">${b.stock}</span></td>
              <td class="actions">
                <button class="link-btn" type="button" data-action="book-edit" data-id="${b.id}">Edit</button>
                <button class="link-btn danger" type="button" data-action="book-delete" data-id="${b.id}" data-title="${esc(b.title)}">Delete</button>
              </td>
            </tr>`).join("") || '<tr><td colspan="5" class="muted">No books found.</td></tr>'}</tbody>
        </table></div>
        <nav class="pager">${pagerHtml(res.pagination, "admin-page")}</nav>`;
    } else if (state.adminTab === "orders") {
      const orders = (await state.api.adminOrders(state.adminOrderFilter)).data;
      box.innerHTML = `
        <div class="row between wrap toolbar-lite">
          <label class="field inline"><span>Status</span>
            <select id="admin-order-filter">
              ${["", "placed", "shipped", "delivered", "cancelled"].map((s) => `<option value="${s}" ${s === state.adminOrderFilter ? "selected" : ""}>${s || "All orders"}</option>`).join("")}
            </select></label>
          <span class="muted">${orders.length} order${orders.length === 1 ? "" : "s"}</span>
        </div>
        <div class="card table-card"><table class="table">
          <thead><tr><th>#</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>${orders.map((o) => `
            <tr>
              <td data-label="#">${o.id}</td>
              <td data-label="Customer"><strong>${esc(o.customerName)}</strong><br><span class="muted">${esc(o.customerEmail)}</span></td>
              <td data-label="Date">${fmtDate(o.created_at)}</td>
              <td data-label="Total">${money(o.total)}</td>
              <td data-label="Status">${statusBadge(o.status)}</td>
              <td class="actions">
                ${o.status === "placed" ? `<button class="btn small" type="button" data-action="order-status" data-id="${o.id}" data-status="shipped">Mark shipped</button>
                  <button class="link-btn danger" type="button" data-action="order-status" data-id="${o.id}" data-status="cancelled">Cancel</button>` : ""}
                ${o.status === "shipped" ? `<button class="btn small" type="button" data-action="order-status" data-id="${o.id}" data-status="delivered">Mark delivered</button>` : ""}
              </td>
            </tr>`).join("") || '<tr><td colspan="6" class="muted">No orders.</td></tr>'}</tbody>
        </table></div>`;
    } else {
      const users = (await state.api.adminUsers()).data;
      box.innerHTML = `
        <div class="card table-card"><table class="table">
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Orders</th><th>Joined</th></tr></thead>
          <tbody>${users.map((u) => `
            <tr><td data-label="#">${u.id}</td><td data-label="Name">${esc(u.name)}</td><td data-label="Email">${esc(u.email)}</td>
              <td data-label="Role"><span class="status ${u.role === "admin" ? "shipped" : "placed"}">${u.role}</span></td>
              <td data-label="Orders">${u.orders}</td><td data-label="Joined">${fmtDate(u.createdAt)}</td></tr>`).join("")}</tbody>
        </table></div>`;
    }
  }

  function bookFormHtml(b = {}) {
    const f = (id, label, type, value, extra = "") => `
      <label class="field"><span>${label}</span><input id="bf-${id}" type="${type}" value="${esc(value ?? "")}" ${extra} /><small class="err" data-err="${id}"></small></label>`;
    return `
      <form id="book-form" data-id="${b.id || ""}" novalidate>
        ${f("title", "Title", "text", b.title)}
        ${f("author", "Author", "text", b.author)}
        <div class="grid-2">
          ${f("category", "Category", "text", b.category, 'list="cat-list"')}
          ${f("year", "Year", "number", b.year, 'min="1000"')}
          ${f("price", "Price (₹)", "number", b.price, 'min="1" step="1"')}
          ${f("stock", "Stock", "number", b.stock ?? 10, 'min="0" step="1"')}
        </div>
        <datalist id="cat-list">${["Fiction", "Technology", "Science", "Biography", "Fantasy", "Classic", "Finance", "Self-Help", "History", "Poetry", "Historical"].map((c) => `<option value="${c}">`).join("")}</datalist>
        <label class="field"><span>Description</span><textarea id="bf-description" rows="3">${esc(b.description ?? "")}</textarea><small class="err" data-err="description"></small></label>
        <p class="form-error" id="book-error" role="alert"></p>
        <div class="row end"><button class="btn outline" type="button" data-action="close-modal">Cancel</button>
          <button class="btn" type="submit">${b.id ? "Save changes" : "Add book"}</button></div>
      </form>`;
  }

  /* ===================== settings ===================== */
  function openSettings() {
    openModal("Choose the backend", `
      <form id="settings-form">
        <label class="choice"><input type="radio" name="mode" value="local" ${state.mode === "local" ? "checked" : ""} />
          <span><strong>🧪 Browser backend</strong><br><small>Works right now by just opening this file. Data is kept in this browser (localStorage).</small></span></label>
        <label class="choice"><input type="radio" name="mode" value="remote" ${state.mode === "remote" ? "checked" : ""} />
          <span><strong>🖥️ Node server</strong><br><small>Uses the real Express + SQLite backend from the <code>server</code> folder (run <code>npm start</code> there first).</small></span></label>
        <label class="field"><span>Server address</span><input id="server-url" type="url" value="${esc(state.serverUrl)}" /></label>
        <p class="form-note" id="settings-msg" role="status"></p>
        <div class="row between wrap">
          <button class="link-btn" type="button" data-action="settings-test">Test connection</button>
          <button class="link-btn danger" type="button" data-action="settings-reset">Reset browser data</button>
        </div>
        <div class="row end"><button class="btn outline" type="button" data-action="close-modal">Cancel</button><button class="btn" type="submit">Save &amp; connect</button></div>
      </form>`);
  }

  /* ===================== click actions ===================== */
  const actions = {
    async details(el) {
      const b = (await state.api.getBook(el.dataset.id)).data;
      openModal(b.title, `
        <div class="detail">
          <div class="cover" style="--cover-bg:${coverBg(b.title)}"><span class="cover-cat">${esc(b.category)}</span><span class="cover-title">${esc(b.title)}</span><span class="cover-author">${esc(b.author)}</span></div>
          <div>
            <p class="muted">by ${esc(b.author)}</p>
            <p>${esc(b.description || "No description available.")}</p>
            <dl class="facts">
              <div><dt>Category</dt><dd>${esc(b.category)}</dd></div>
              <div><dt>Published</dt><dd>${b.year ?? "–"}</dd></div>
              <div><dt>Rating</dt><dd>${b.rating != null ? "★ " + b.rating.toFixed(1) : "–"}</dd></div>
              <div><dt>Price</dt><dd>${money(b.price)}</dd></div>
            </dl>
            ${stockBadge(b)}
            <div class="row end"><button class="btn" type="button" data-action="add" data-id="${b.id}" ${b.stock === 0 ? "disabled" : ""}>Add to cart</button></div>
          </div>
        </div>`);
    },
    async add(el) {
      if (!state.user) return requireLogin();
      state.cart = await state.api.addToCart({ bookId: Number(el.dataset.id), quantity: 1 });
      renderHeader();
      toast("Added to cart 🛒");
      if (!$("#modal").classList.contains("hidden")) closeModal();
    },
    async qty(el) {
      state.cart = await state.api.setCartQty(el.dataset.id, Number(el.dataset.qty));
      await viewCart();
    },
    async remove(el) {
      state.cart = await state.api.removeFromCart(el.dataset.id);
      await viewCart();
    },
    async "clear-cart"() {
      state.cart = await state.api.clearCart();
      await viewCart();
    },
    async "cancel-order"(el) {
      if (!confirm("Cancel this order? The books go back into stock.")) return;
      await state.api.cancelOrder(el.dataset.id);
      toast("Order cancelled.");
      await viewOrders();
    },
    async logout() {
      await state.api.logout();
      state.user = null; state.cart = emptyCart();
      savePref(); renderHeader();
      toast("Logged out.");
      navigate("#/");
    },
    "shop-page"(el) { state.shop.page = Number(el.dataset.page); return loadShop().then(() => $("#shop-results").scrollIntoView({ behavior: "smooth", block: "start" })); },
    "admin-tab"(el) { state.adminTab = el.dataset.tab; return viewAdmin(); },
    "admin-page"(el) { state.adminBooks.page = Number(el.dataset.page); return loadAdminTab(); },
    "book-new"() { openModal("Add a book", bookFormHtml()); },
    async "book-edit"(el) {
      const b = (await state.api.getBook(el.dataset.id)).data;
      openModal("Edit book", bookFormHtml(b));
    },
    async "book-delete"(el) {
      if (!confirm(`Delete "${el.dataset.title}"? Old orders keep their records.`)) return;
      await state.api.deleteBook(el.dataset.id);
      toast("Book deleted.");
      await loadAdminTab();
    },
    async "order-status"(el) {
      if (el.dataset.status === "cancelled" && !confirm("Cancel this order? Stock will be restored.")) return;
      await state.api.adminSetStatus(el.dataset.id, el.dataset.status);
      toast(`Order #${el.dataset.id} marked ${el.dataset.status}.`);
      await loadAdminTab();
    },
    "demo-fill"(el) {
      $("#login-email").value = el.dataset.email;
      $("#login-password").value = el.dataset.pass;
    },
    settings: () => openSettings(),
    "close-modal": () => closeModal(),
    async "settings-test"() {
      const msg = $("#settings-msg");
      msg.textContent = "Testing…"; msg.className = "form-note";
      try {
        await window.RemoteApi.create($("#server-url").value, null).health();
        msg.textContent = "✔ Connected. The Node server is running."; msg.className = "form-note good";
      } catch (e) { msg.textContent = "✖ " + e.message; msg.className = "form-note bad"; }
    },
    async "settings-reset"() {
      if (!confirm("Reset the browser backend? All its users, orders and changes are erased and the sample data is restored.")) return;
      const local = await window.LocalApi.create(null);
      await local.resetData();
      state.mode = "local";
      state.afterLogin = null;
      await connect(null);
      closeModal();
      toast("Browser data reset.");
      navigate("#/");
    },
    "log-toggle"() {
      const panel = $("#log-panel");
      const open = panel.classList.toggle("hidden") === false;
      const btn = $("#log-toggle");
      btn.setAttribute("aria-expanded", String(open));
      btn.firstChild.textContent = open ? "📡 Hide API log " : "📡 Show API log ";
      if (open) { renderLog(); panel.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
    },
    "log-clear"() { state.logs = []; $("#log-count").textContent = "0"; renderLog(); },
  };

  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-action]");
    if (el) {
      const fn = actions[el.dataset.action];
      if (fn) { e.preventDefault(); guard(fn)(el); }
      return;
    }
    if (e.target === $("#modal")) closeModal();
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

  /* ===================== form / input handlers ===================== */
  function showFieldErrors(form, details) {
    form.querySelectorAll("[data-err]").forEach((el) => (el.textContent = (details && details[el.dataset.err]) || ""));
  }

  const forms = {
    async "login-form"() {
      const err = $("#form-error");
      err.textContent = "";
      try {
        const res = await state.api.login({ email: $("#login-email").value, password: $("#login-password").value });
        await finishLogin(res);
      } catch (e) {
        if (e instanceof ApiError && e.status !== 0) err.textContent = e.message; else throw e;
      }
    },
    async "register-form"(form) {
      $("#form-error").textContent = "";
      showFieldErrors(form, null);
      try {
        const res = await state.api.register({ name: $("#reg-name").value, email: $("#reg-email").value, password: $("#reg-password").value });
        await finishLogin(res);
      } catch (e) {
        if (e instanceof ApiError && e.status !== 0) {
          showFieldErrors(form, e.details);
          if (!e.details) $("#form-error").textContent = e.message;
        } else throw e;
      }
    },
    async "checkout-form"() {
      const err = $("#checkout-error");
      err.textContent = "";
      const address = $("#ship-address").value;
      try {
        const res = await state.api.checkout(address);
        try { localStorage.setItem(ADDR_KEY, address.trim()); } catch { /* ignore */ }
        state.cart = emptyCart();
        renderHeader();
        toast(`Order #${res.data.id} placed! Total ${money(res.data.total)}`);
        navigate("#/orders");
      } catch (e) {
        if (e instanceof ApiError && e.status !== 0 && e.status !== 401) err.textContent = e.details && e.details.shippingAddress ? "Please enter your full shipping address (at least 10 characters)." : e.message; else throw e;
      }
    },
    async "book-form"(form) {
      const val = (id) => $("#bf-" + id).value;
      const body = { title: val("title"), author: val("author"), category: val("category"), price: val("price"), stock: val("stock") };
      if (val("year") !== "") body.year = val("year");
      if (val("description").trim() !== "") body.description = val("description");
      showFieldErrors(form, null);
      $("#book-error").textContent = "";
      try {
        if (form.dataset.id) await state.api.updateBook(form.dataset.id, body); else await state.api.createBook(body);
      } catch (e) {
        if (e instanceof ApiError && e.status === 400) { showFieldErrors(form, e.details); if (!e.details) $("#book-error").textContent = e.message; return; }
        throw e;
      }
      closeModal();
      toast(form.dataset.id ? "Book updated." : "Book added.");
      await loadAdminTab();
    },
    async "settings-form"(form) {
      const mode = form.elements.mode.value;
      state.mode = mode;
      state.serverUrl = $("#server-url").value.trim() || DEFAULT_URL;
      state.afterLogin = null;
      await connect(null);
      closeModal();
      toast(state.mode === "remote" ? "Connected to the Node server." : "Using the browser backend.");
      navigate("#/");
    },
  };

  document.addEventListener("submit", (e) => {
    const handler = forms[e.target.id];
    if (!handler) return;
    e.preventDefault();
    guard(handler)(e.target);
  });

  document.addEventListener("input", (e) => {
    if (e.target.dataset.shop === "search") onShopControl(e.target);
    if (e.target.id === "admin-book-search") {
      state.adminBooks.search = e.target.value;
      state.adminBooks.page = 1;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(async () => {
        const pos = e.target.selectionStart;
        await guard(loadAdminTab)();
        const box = $("#admin-book-search");
        if (box) { box.focus(); box.setSelectionRange(pos, pos); }
      }, 250);
    }
  });
  document.addEventListener("change", (e) => {
    if (e.target.dataset.shop && e.target.dataset.shop !== "search") onShopControl(e.target);
    if (e.target.id === "admin-order-filter") {
      state.adminOrderFilter = e.target.value;
      guard(loadAdminTab)();
    }
  });

  /* ===================== start ===================== */
  async function init() {
    const pref = loadPref();
    state.mode = pref.mode === "remote" ? "remote" : "local";
    state.serverUrl = pref.url || DEFAULT_URL;
    try {
      await connect(pref.token || null);
    } catch (e) {
      console.error(e);
      view.innerHTML = `<div class="empty"><p>Could not start the app: ${esc(e.message)}</p></div>`;
      return;
    }
    window.addEventListener("hashchange", route);
    route();
  }
  init();
})();
